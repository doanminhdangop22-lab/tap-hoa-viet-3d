extends Node

var foods_list: Array = []
var foods_by_id: Dictionary = {}
var skins_list: Array = []
var skins_by_id: Dictionary = {}
var decor_list: Array = []
var decor_by_id: Dictionary = {}
var _icon_cache: Dictionary = {}

const CATEGORY_NAMES: Dictionary = {
	"all": "Tất cả",
	"snack": "Snack",
	"sweet": "Ngọt",
	"drink": "Nước",
	"noodle": "Mì",
	"icecream": "Kem"
}

func _ready() -> void:
	_load_foods()
	_load_skins()
	_load_decor()

func _load_json_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("Missing data file: " + path)
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var text := file.get_as_text()
	file.close()
	var parsed: Variant = JSON.parse_string(text)
	if parsed is Dictionary:
		return parsed
	return {}

func _load_foods() -> void:
	var data := _load_json_file("res://data/foods.json")
	foods_list = data.get("foods", [])
	foods_by_id.clear()
	for item in foods_list:
		if item is Dictionary and item.has("id"):
			foods_by_id[String(item["id"])] = item

func _load_skins() -> void:
	var data := _load_json_file("res://data/skins.json")
	skins_list = data.get("skins", [])
	skins_by_id.clear()
	for item in skins_list:
		if item is Dictionary and item.has("id"):
			skins_by_id[String(item["id"])] = item

func _load_decor() -> void:
	var data := _load_json_file("res://data/decor.json")
	decor_list = data.get("decor", [])
	decor_by_id.clear()
	for item in decor_list:
		if item is Dictionary and item.has("id"):
			decor_by_id[String(item["id"])] = item

func get_all_foods() -> Array:
	return foods_list

func get_foods_by_category(category: String) -> Array:
	if category == "" or category == "all":
		return foods_list
	var result: Array = []
	for item in foods_list:
		if String(item.get("category", "")) == category:
			result.append(item)
	return result

func get_food(food_id: String) -> Dictionary:
	return foods_by_id.get(food_id, {})

func get_skin(skin_id: String) -> Dictionary:
	return skins_by_id.get(skin_id, {})

func get_all_skins() -> Array:
	return skins_list

func get_decor(decor_id: String) -> Dictionary:
	return decor_by_id.get(decor_id, {})

func get_all_decor() -> Array:
	return decor_list

func get_icon(path: String) -> Texture2D:
	if path == "":
		return null
	if _icon_cache.has(path):
		return _icon_cache[path]
	if ResourceLoader.exists(path):
		var tex := load(path) as Texture2D
		if tex != null:
			_icon_cache[path] = tex
			return tex
	return null

func get_food_icon(food_id: String) -> Texture2D:
	var f := get_food(food_id)
	return get_icon(String(f.get("icon_path", "")))

func get_skin_icon(skin_id: String) -> Texture2D:
	var s := get_skin(skin_id)
	return get_icon(String(s.get("icon_path", "")))

func get_decor_icon(decor_id: String) -> Texture2D:
	var d := get_decor(decor_id)
	return get_icon(String(d.get("icon_path", "")))

func get_category_name(cat: String) -> String:
	return CATEGORY_NAMES.get(cat, cat)
