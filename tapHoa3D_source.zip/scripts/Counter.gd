extends StaticBody3D

var _waiting_slots: Array = [null, null, null, null, null, null]
var _visual_root: Node3D
var _pos_screen_mat: StandardMaterial3D
var _label_3d: Label3D

const SLOT_OFFSETS: Array[Vector3] = [
	Vector3(-1.35, 0.0, 1.45),
	Vector3(0.0, 0.0, 1.50),
	Vector3(1.35, 0.0, 1.45),
	Vector3(-2.05, 0.0, 2.35),
	Vector3(-0.55, 0.0, 2.45),
	Vector3(0.95, 0.0, 2.45)
]

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("counter")
	_build_counter_visuals()
	GameSys.decor_updated.connect(_refresh_pos_upgrade)

func _build_counter_visuals() -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.40, 1.25, 1.15)
	col.shape = shape
	col.position = Vector3(0, 0.62, 0)
	add_child(col)

	_visual_root = Node3D.new()
	_visual_root.name = "VisualRoot"
	add_child(_visual_root)

	var body := MeshInstance3D.new()
	if ResourceLoader.exists("res://assets/models/counter.obj"):
		body.mesh = load("res://assets/models/counter.obj") as Mesh
	else:
		var bm := BoxMesh.new()
		bm.size = Vector3(2.2, 1.05, 0.95)
		body.mesh = bm
		body.position = Vector3(0, 0.52, 0)
	var wood_mat := StandardMaterial3D.new()
	wood_mat.albedo_color = Color(0.93, 0.68, 0.36)
	wood_mat.roughness = 0.55
	body.material_override = wood_mat
	_visual_root.add_child(body)

	# White marble countertop accent
	var top := MeshInstance3D.new()
	var tb := BoxMesh.new()
	tb.size = Vector3(2.36, 0.10, 1.05)
	top.mesh = tb
	top.position = Vector3(0, 1.06, 0)
	var top_mat := StandardMaterial3D.new()
	top_mat.albedo_color = Color(0.98, 0.97, 0.94)
	top.material_override = top_mat
	_visual_root.add_child(top)

	# Cash Register / POS Machine
	var reg := MeshInstance3D.new()
	var rb := BoxMesh.new()
	rb.size = Vector3(0.52, 0.32, 0.42)
	reg.mesh = rb
	reg.position = Vector3(-0.55, 1.24, 0.05)
	var reg_mat := StandardMaterial3D.new()
	reg_mat.albedo_color = Color(0.24, 0.28, 0.32)
	reg.material_override = reg_mat
	_visual_root.add_child(reg)

	var screen := MeshInstance3D.new()
	var sb := BoxMesh.new()
	sb.size = Vector3(0.42, 0.28, 0.06)
	screen.mesh = sb
	screen.position = Vector3(-0.55, 1.48, 0.12)
	screen.rotation_degrees = Vector3(-18, 0, 0)
	_pos_screen_mat = StandardMaterial3D.new()
	_pos_screen_mat.albedo_color = Color(0.25, 0.92, 0.65)
	_pos_screen_mat.emission_enabled = true
	_pos_screen_mat.emission = Color(0.15, 0.75, 0.55)
	screen.material_override = _pos_screen_mat
	_visual_root.add_child(screen)

	# Floating "QUẦY THU NGÂN" label
	var font := load("res://assets/fonts/BeVietnamPro-ExtraBold.ttf") as Font
	_label_3d = Label3D.new()
	_label_3d.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label_3d.font = font
	_label_3d.font_size = 34
	_label_3d.outline_size = 10
	_label_3d.text = "💰 QUẦY THU NGÂN"
	_label_3d.modulate = Color(1.0, 0.92, 0.35)
	_label_3d.outline_modulate = Color(0.14, 0.10, 0.06)
	_label_3d.pixel_size = 0.0044
	_label_3d.position = Vector3(0, 1.92, 0)
	add_child(_label_3d)

	_refresh_pos_upgrade()

func _refresh_pos_upgrade() -> void:
	if _pos_screen_mat == null:
		return
	if GameSys.has_decor_placed("modern_pos"):
		_pos_screen_mat.albedo_color = Color(0.10, 0.90, 1.0)
		_pos_screen_mat.emission = Color(0.0, 0.82, 1.0)
	else:
		_pos_screen_mat.albedo_color = Color(0.25, 0.92, 0.65)
		_pos_screen_mat.emission = Color(0.15, 0.75, 0.55)

func get_stand_point() -> Vector3:
	return global_position + Vector3(0.0, 0.0, -1.05)

func claim_waiting_slot(customer: Node3D) -> int:
	for i in range(_waiting_slots.size()):
		if _waiting_slots[i] == null or not is_instance_valid(_waiting_slots[i]):
			_waiting_slots[i] = customer
			return i
	return -1

func release_waiting_slot(customer: Node3D) -> void:
	for i in range(_waiting_slots.size()):
		if _waiting_slots[i] == customer:
			_waiting_slots[i] = null

func get_slot_world_position(slot_idx: int) -> Vector3:
	var idx := clampi(slot_idx, 0, SLOT_OFFSETS.size() - 1)
	return global_position + SLOT_OFFSETS[idx]

func on_customer_arrived() -> void:
	if _visual_root == null:
		return
	var tw := create_tween()
	tw.tween_property(_visual_root, "scale", Vector3(1.06, 0.93, 1.06), 0.07)
	tw.tween_property(_visual_root, "rotation_degrees:z", 2.5, 0.06)
	tw.tween_property(_visual_root, "rotation_degrees:z", -2.5, 0.06)
	tw.tween_property(_visual_root, "rotation_degrees:z", 0.0, 0.06)
	tw.tween_property(_visual_root, "scale", Vector3.ONE, 0.10).set_trans(Tween.TRANS_BACK)

func on_player_interact(player: Node3D) -> void:
	var basket_items: Array = player.get("basket")
	if basket_items == null or basket_items.is_empty():
		GameSys.show_toast("Giỏ tay đang trống! Hãy lại kệ lấy đồ khách cần trước.", "info")
		return

	var waiting_customers: Array[Node3D] = []
	for c in _waiting_slots:
		if c != null and is_instance_valid(c) and bool(c.call("is_waiting_for_order")):
			waiting_customers.append(c)

	if waiting_customers.is_empty():
		GameSys.show_toast("Chưa có khách nào đứng chờ ở quầy thu ngân!", "info")
		return

	# Sort by lowest mood first so urgent customers get served first!
	waiting_customers.sort_custom(func(a: Node3D, b: Node3D) -> bool:
		return float(a.get("mood_ratio")) < float(b.get("mood_ratio"))
	)

	var delivered_any := false
	var copy_basket := basket_items.duplicate()
	for fid in copy_basket:
		var item_str := String(fid)
		for cust in waiting_customers:
			if is_instance_valid(cust) and bool(cust.call("needs_item", item_str)):
				if bool(player.call("remove_from_basket", item_str)):
					delivered_any = true
					var is_combo := GameSys.record_item_sold(item_str)
					cust.call("deliver_item", item_str, is_combo)
					break

	if delivered_any:
		AudioSys.play_sfx("sell_ting", 0.04)
		on_customer_arrived()
	else:
		GameSys.show_toast("Món trong giỏ không khớp với order của khách đang chờ!", "warn")
