extends CharacterBody3D

signal basket_changed(items: Array[String])

const BASE_SPEED := 6.2
const MAX_BASKET_SIZE := 6
const INTERACT_RANGE := 2.35
const STORE_BOUNDS_X := Vector2(-4.85, 4.85)
const STORE_BOUNDS_Z := Vector2(-5.35, 5.85)

var basket: Array[String] = []
var joystick_input: Vector2 = Vector2.ZERO
var ui_blocking_input: bool = false

var _move_target: Vector3 = Vector3.ZERO
var _has_move_target: bool = false
var _pending_interact_node: Node3D = null
var _walk_phase: float = 0.0
var _speed_bonus: float = 0.0

var _visual_root: Node3D
var _left_leg: Node3D
var _right_leg: Node3D
var _left_arm: Node3D
var _right_arm: Node3D
var _tail_or_cape: Node3D
var _basket_items_root: Node3D
var _target_marker: MeshInstance3D

func _ready() -> void:
	add_to_group("player")
	_build_visual_rig()
	_create_target_marker()
	apply_skin(GameSys.get_equipped_skin())
	GameSys.skin_changed.connect(apply_skin)

func _exit_tree() -> void:
	if _target_marker != null and is_instance_valid(_target_marker):
		_target_marker.queue_free()

func _create_target_marker() -> void:
	_target_marker = MeshInstance3D.new()
	var torus := CylinderMesh.new()
	torus.top_radius = 0.38
	torus.bottom_radius = 0.38
	torus.height = 0.03
	_target_marker.mesh = torus
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.82, 0.15, 0.78)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_target_marker.material_override = mat
	_target_marker.visible = false
	get_parent().call_deferred("add_child", _target_marker)

func _build_visual_rig() -> void:
	_visual_root = Node3D.new()
	_visual_root.name = "VisualRig"
	add_child(_visual_root)
	populate_character_meshes(_visual_root, GameSys.get_equipped_skin(), true)
	_left_leg = _visual_root.get_node_or_null("LeftLeg")
	_right_leg = _visual_root.get_node_or_null("RightLeg")
	_left_arm = _visual_root.get_node_or_null("LeftArm")
	_right_arm = _visual_root.get_node_or_null("RightArm")
	_tail_or_cape = _visual_root.get_node_or_null("BackAccessory")
	_basket_items_root = _visual_root.get_node_or_null("RightArm/Basket/ItemsRoot")

static func populate_character_meshes(root: Node3D, skin_id: String, with_basket: bool) -> void:
	for c in root.get_children():
		c.queue_free()

	var skin := FoodDB.get_skin(skin_id)
	var body_col := Color.from_string(String(skin.get("body_color", "#26A69A")), Color(0.15, 0.65, 0.6))
	var sec_col := Color.from_string(String(skin.get("secondary_color", "#FFF8E1")), Color(1.0, 0.97, 0.88))
	var acc_col := Color.from_string(String(skin.get("accent_color", "#FFB300")), Color(1.0, 0.7, 0.0))
	var hat_type := String(skin.get("hat_type", "visor"))
	var skin_tone := Color(1.0, 0.86, 0.74)
	var hair_col := Color(0.24, 0.16, 0.12)

	# Shadow blob
	var shadow := MeshInstance3D.new()
	var sh_mesh := CylinderMesh.new()
	sh_mesh.top_radius = 0.42
	sh_mesh.bottom_radius = 0.42
	sh_mesh.height = 0.02
	shadow.mesh = sh_mesh
	var sh_mat := StandardMaterial3D.new()
	sh_mat.albedo_color = Color(0, 0, 0, 0.28)
	sh_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sh_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow.material_override = sh_mat
	shadow.position = Vector3(0, 0.02, 0)
	root.add_child(shadow)

	# Legs
	for side in [-1, 1]:
		var leg_pivot := Node3D.new()
		leg_pivot.name = "LeftLeg" if side < 0 else "RightLeg"
		leg_pivot.position = Vector3(side * 0.14, 0.34, 0)
		var leg_mesh := MeshInstance3D.new()
		var cap := CapsuleMesh.new()
		cap.radius = 0.09
		cap.height = 0.36
		leg_mesh.mesh = cap
		leg_mesh.position = Vector3(0, -0.16, 0)
		leg_mesh.material_override = _make_mat(Color(0.22, 0.26, 0.34))
		leg_pivot.add_child(leg_mesh)
		root.add_child(leg_pivot)

	# Torso
	var torso := MeshInstance3D.new()
	var t_mesh := CylinderMesh.new()
	t_mesh.top_radius = 0.24
	t_mesh.bottom_radius = 0.28
	t_mesh.height = 0.56
	torso.mesh = t_mesh
	torso.position = Vector3(0, 0.62, 0)
	torso.material_override = _make_mat(body_col)
	root.add_child(torso)

	# Apron / Sash front detail
	var apron := MeshInstance3D.new()
	var ap_box := BoxMesh.new()
	ap_box.size = Vector3(0.34, 0.42, 0.14)
	apron.mesh = ap_box
	apron.position = Vector3(0, 0.58, 0.22)
	apron.material_override = _make_mat(sec_col)
	root.add_child(apron)

	# Head
	var head := MeshInstance3D.new()
	var h_sphere := SphereMesh.new()
	h_sphere.radius = 0.29
	h_sphere.height = 0.56
	head.mesh = h_sphere
	head.position = Vector3(0, 1.18, 0)
	head.material_override = _make_mat(skin_tone)
	root.add_child(head)

	# Hair back cap
	var hair := MeshInstance3D.new()
	var hair_s := SphereMesh.new()
	hair_s.radius = 0.305
	hair_s.height = 0.52
	hair.mesh = hair_s
	hair.position = Vector3(0, 1.23, -0.03)
	hair.material_override = _make_mat(hair_col)
	root.add_child(hair)

	# Eyes & Rosy Cheeks
	for side in [-1, 1]:
		var eye := MeshInstance3D.new()
		var es := SphereMesh.new()
		es.radius = 0.042
		es.height = 0.084
		eye.mesh = es
		eye.position = Vector3(side * 0.10, 1.19, 0.26)
		eye.material_override = _make_mat(Color(0.1, 0.1, 0.12))
		root.add_child(eye)

		var cheek := MeshInstance3D.new()
		var cs := SphereMesh.new()
		cs.radius = 0.045
		cs.height = 0.05
		cheek.mesh = cs
		cheek.position = Vector3(side * 0.17, 1.12, 0.24)
		cheek.material_override = _make_mat(Color(1.0, 0.52, 0.58))
		root.add_child(cheek)

	# Hat / Costume Accessories
	var back_acc := Node3D.new()
	back_acc.name = "BackAccessory"
	back_acc.position = Vector3(0, 0.78, -0.24)
	root.add_child(back_acc)

	match hat_type:
		"chef":
			var rim := MeshInstance3D.new()
			var rc := CylinderMesh.new()
			rc.top_radius = 0.28
			rc.bottom_radius = 0.27
			rc.height = 0.14
			rim.mesh = rc
			rim.position = Vector3(0, 1.44, 0)
			rim.material_override = _make_mat(Color.WHITE)
			root.add_child(rim)
			var puff := MeshInstance3D.new()
			var ps := SphereMesh.new()
			ps.radius = 0.33
			ps.height = 0.42
			puff.mesh = ps
			puff.position = Vector3(0, 1.62, 0)
			puff.material_override = _make_mat(Color.WHITE)
			root.add_child(puff)
		"cat_ears":
			for side in [-1, 1]:
				var ear := MeshInstance3D.new()
				var prism := PrismMesh.new()
				prism.size = Vector3(0.18, 0.22, 0.10)
				ear.mesh = prism
				ear.position = Vector3(side * 0.18, 1.48, 0.04)
				ear.rotation_degrees = Vector3(0, 0, -side * 16.0)
				ear.material_override = _make_mat(body_col)
				root.add_child(ear)
			var tail := MeshInstance3D.new()
			var tc := CapsuleMesh.new()
			tc.radius = 0.05
			tc.height = 0.46
			tail.mesh = tc
			tail.position = Vector3(0, -0.22, -0.14)
			tail.rotation_degrees = Vector3(50, 0, 0)
			tail.material_override = _make_mat(body_col)
			back_acc.add_child(tail)
		"hero_cape":
			var mask := MeshInstance3D.new()
			var mb := BoxMesh.new()
			mb.size = Vector3(0.42, 0.12, 0.14)
			mask.mesh = mb
			mask.position = Vector3(0, 1.20, 0.23)
			mask.material_override = _make_mat(sec_col)
			root.add_child(mask)
			var cape := MeshInstance3D.new()
			var cb := BoxMesh.new()
			cb.size = Vector3(0.56, 0.68, 0.05)
			cape.mesh = cb
			cape.position = Vector3(0, -0.26, -0.06)
			cape.rotation_degrees = Vector3(14, 0, 0)
			cape.material_override = _make_mat(sec_col)
			back_acc.add_child(cape)
		"flower_band":
			var flower := MeshInstance3D.new()
			var fs := SphereMesh.new()
			fs.radius = 0.11
			fs.height = 0.16
			flower.mesh = fs
			flower.position = Vector3(0.24, 1.38, 0.14)
			flower.material_override = _make_mat(acc_col)
			root.add_child(flower)
		_:
			var cap_top := MeshInstance3D.new()
			var cs := SphereMesh.new()
			cs.radius = 0.30
			cs.height = 0.32
			cap_top.mesh = cs
			cap_top.position = Vector3(0, 1.37, 0)
			cap_top.material_override = _make_mat(acc_col)
			root.add_child(cap_top)
			var brim := MeshInstance3D.new()
			var bb := BoxMesh.new()
			bb.size = Vector3(0.36, 0.04, 0.24)
			brim.mesh = bb
			brim.position = Vector3(0, 1.34, 0.24)
			brim.material_override = _make_mat(acc_col)
			root.add_child(brim)

	# Arms & Basket
	for side in [-1, 1]:
		var arm_pivot := Node3D.new()
		arm_pivot.name = "LeftArm" if side < 0 else "RightArm"
		arm_pivot.position = Vector3(side * 0.30, 0.80, 0)
		var arm_mesh := MeshInstance3D.new()
		var ac := CapsuleMesh.new()
		ac.radius = 0.075
		ac.height = 0.36
		arm_mesh.mesh = ac
		arm_mesh.position = Vector3(0, -0.14, 0.06)
		arm_mesh.rotation_degrees = Vector3(-25, 0, 0)
		arm_mesh.material_override = _make_mat(body_col)
		arm_pivot.add_child(arm_mesh)

		if side > 0 and with_basket:
			var basket_node := Node3D.new()
			basket_node.name = "Basket"
			basket_node.position = Vector3(0.06, -0.24, 0.28)
			var tray := MeshInstance3D.new()
			var tb := BoxMesh.new()
			tb.size = Vector3(0.42, 0.18, 0.34)
			tray.mesh = tb
			tray.material_override = _make_mat(Color(1.0, 0.68, 0.12))
			basket_node.add_child(tray)
			var items_root := Node3D.new()
			items_root.name = "ItemsRoot"
			items_root.position = Vector3(0, 0.12, 0)
			basket_node.add_child(items_root)
			arm_pivot.add_child(basket_node)

		root.add_child(arm_pivot)

static func _make_mat(col: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.65
	return m

func apply_skin(skin_id: String) -> void:
	var skin := FoodDB.get_skin(skin_id)
	_speed_bonus = float(skin.get("speed_bonus", 0.0))
	if _visual_root != null:
		populate_character_meshes(_visual_root, skin_id, true)
		_left_leg = _visual_root.get_node_or_null("LeftLeg")
		_right_leg = _visual_root.get_node_or_null("RightLeg")
		_left_arm = _visual_root.get_node_or_null("LeftArm")
		_right_arm = _visual_root.get_node_or_null("RightArm")
		_tail_or_cape = _visual_root.get_node_or_null("BackAccessory")
		_basket_items_root = _visual_root.get_node_or_null("RightArm/Basket/ItemsRoot")
		_rebuild_basket_visuals()

func set_joystick_input(vec: Vector2) -> void:
	joystick_input = vec
	if vec.length_squared() > 0.02:
		_has_move_target = false
		_pending_interact_node = null

func command_move_to(world_pos: Vector3, interact_target: Node3D = null) -> void:
	if ui_blocking_input:
		return
	var clamped := Vector3(
		clampf(world_pos.x, STORE_BOUNDS_X.x, STORE_BOUNDS_X.y),
		0.0,
		clampf(world_pos.z, STORE_BOUNDS_Z.x, STORE_BOUNDS_Z.y)
	)
	_move_target = clamped
	_has_move_target = true
	_pending_interact_node = interact_target
	if _target_marker != null:
		_target_marker.global_position = Vector3(clamped.x, 0.04, clamped.z)
		_target_marker.visible = true

func _unhandled_input(event: InputEvent) -> void:
	if ui_blocking_input:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		var ke := event as InputEventKey
		if ke.keycode == KEY_E or ke.keycode == KEY_SPACE:
			interact_nearest()
			get_viewport().set_input_as_handled()
		elif ke.keycode == KEY_Q or ke.keycode == KEY_BACKSPACE:
			discard_last_basket_item()
			get_viewport().set_input_as_handled()

func _get_keyboard_input() -> Vector2:
	var dir := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		dir.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		dir.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		dir.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		dir.y += 1.0
	return dir.limit_length(1.0)

func _physics_process(delta: float) -> void:
	if ui_blocking_input:
		velocity = Vector3.ZERO
		_animate_character(delta, false)
		return

	var input_vec := _get_keyboard_input()
	if joystick_input.length_squared() > input_vec.length_squared():
		input_vec = joystick_input

	var move_dir := Vector3.ZERO
	if input_vec.length_squared() > 0.02:
		_has_move_target = false
		_pending_interact_node = null
		if _target_marker != null:
			_target_marker.visible = false
		move_dir = Vector3(input_vec.x, 0.0, input_vec.y).normalized()
	elif _has_move_target:
		var diff := _move_target - global_position
		diff.y = 0.0
		var stop_dist := 0.25 if _pending_interact_node == null else 0.55
		if diff.length() <= stop_dist:
			_has_move_target = false
			if _target_marker != null:
				_target_marker.visible = false
			if _pending_interact_node != null and is_instance_valid(_pending_interact_node):
				var target_node := _pending_interact_node
				_pending_interact_node = null
				_interact_with_node(target_node)
		else:
			move_dir = diff.normalized()

	var spd := BASE_SPEED + _speed_bonus
	velocity.x = move_dir.x * spd
	velocity.z = move_dir.z * spd
	velocity.y = 0.0
	move_and_slide()

	global_position.x = clampf(global_position.x, STORE_BOUNDS_X.x, STORE_BOUNDS_X.y)
	global_position.z = clampf(global_position.z, STORE_BOUNDS_Z.x, STORE_BOUNDS_Z.y)
	global_position.y = 0.0

	var is_moving := move_dir.length_squared() > 0.01
	if is_moving and _visual_root != null:
		var target_angle := atan2(move_dir.x, move_dir.z)
		_visual_root.rotation.y = lerp_angle(_visual_root.rotation.y, target_angle, clampf(delta * 14.0, 0.0, 1.0))

	if _pending_interact_node != null and is_instance_valid(_pending_interact_node):
		var d := global_position.distance_to(_pending_interact_node.global_position)
		if d <= INTERACT_RANGE:
			var n := _pending_interact_node
			_pending_interact_node = null
			_has_move_target = false
			if _target_marker != null:
				_target_marker.visible = false
			_interact_with_node(n)

	_animate_character(delta, is_moving)

func _animate_character(delta: float, is_moving: bool) -> void:
	if is_moving:
		_walk_phase += delta * 13.0
	else:
		_walk_phase = lerpf(_walk_phase, 0.0, clampf(delta * 8.0, 0.0, 1.0))

	var swing := sin(_walk_phase) * (0.55 if is_moving else 0.0)
	if _left_leg != null:
		_left_leg.rotation.x = swing
	if _right_leg != null:
		_right_leg.rotation.x = -swing
	if _left_arm != null:
		_left_arm.rotation.x = -swing * 0.7
	if _right_arm != null:
		_right_arm.rotation.x = -0.45 if not basket.is_empty() else swing * 0.7
	if _tail_or_cape != null:
		_tail_or_cape.rotation.y = sin(Time.get_ticks_msec() * 0.006) * 0.25
	if _visual_root != null:
		_visual_root.position.y = absf(sin(_walk_phase)) * 0.06 if is_moving else sin(Time.get_ticks_msec() * 0.004) * 0.02

func interact_nearest() -> void:
	var best_node: Node3D = null
	var best_dist := INTERACT_RANGE
	for node in get_tree().get_nodes_in_group("interactable"):
		if node is Node3D:
			var n3 := node as Node3D
			var d := global_position.distance_to(n3.global_position)
			if d <= best_dist:
				best_dist = d
				best_node = n3
	if best_node != null:
		_interact_with_node(best_node)
	else:
		GameSys.show_toast("Lại gần kệ hàng hoặc quầy thu ngân để thao tác!", "info")

func _interact_with_node(node: Node3D) -> void:
	if node.has_method("on_player_interact"):
		node.call("on_player_interact", self)

func can_add_to_basket() -> bool:
	return basket.size() < MAX_BASKET_SIZE

func add_to_basket(food_id: String) -> bool:
	if basket.size() >= MAX_BASKET_SIZE:
		GameSys.show_toast("Giỏ tay đã đầy (%d/%d)! Ra quầy bán hoặc bấm Q bỏ bớt." % [basket.size(), MAX_BASKET_SIZE], "warn")
		return false
	basket.append(food_id)
	AudioSys.play_sfx("pickup_item", 0.08)
	_rebuild_basket_visuals()
	basket_changed.emit(basket)
	return true

func remove_from_basket(food_id: String) -> bool:
	var idx := basket.find(food_id)
	if idx == -1:
		return false
	basket.remove_at(idx)
	_rebuild_basket_visuals()
	basket_changed.emit(basket)
	return true

func discard_last_basket_item() -> void:
	if basket.is_empty():
		return
	var last_id: String = basket.pop_back()
	GameSys.add_stock(last_id, 1)
	AudioSys.play_sfx("ui_click")
	_rebuild_basket_visuals()
	basket_changed.emit(basket)
	var f := FoodDB.get_food(last_id)
	GameSys.show_toast("Đã trả %s lại vào kệ!" % String(f.get("name", last_id)), "info")

func _rebuild_basket_visuals() -> void:
	if _basket_items_root == null:
		return
	for c in _basket_items_root.get_children():
		c.queue_free()
	for i in range(basket.size()):
		var fid := basket[i]
		var f := FoodDB.get_food(fid)
		var col := Color.from_string(String(f.get("color", "#FFB300")), Color.ORANGE)
		var item_mesh := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.14, 0.14, 0.14)
		item_mesh.mesh = bm
		var row := int(i / 2)
		var col_idx := i % 2
		item_mesh.position = Vector3(-0.08 + col_idx * 0.16, row * 0.13, 0.0)
		item_mesh.material_override = _make_mat(col)
		_basket_items_root.add_child(item_mesh)
