extends CanvasLayer

signal shop_button_pressed()
signal decor_button_pressed()
signal pause_button_pressed()
signal stats_button_pressed()
signal interact_button_pressed()
signal joystick_updated(vec: Vector2)

var _money_lbl: Label
var _displayed_money: float = 500.0
var _target_money: int = 500

var _stars_lbl: Label
var _sat_lbl: Label
var _light_btn: Button
var _basket_items_hbox: HBoxContainer
var _basket_empty_lbl: Label
var _discard_btn: Button

var _combo_panel: PanelContainer
var _combo_lbl: Label
var _toast_panel: PanelContainer
var _toast_lbl: Label
var _toast_tween: Tween
var _popups_layer: Control

# Virtual Joystick (Android & iPhone + Touch)
var _joy_base: Control
var _joy_knob: Control
var _joy_touch_idx: int = -1
var _joy_mouse_dragging: bool = false
const JOY_RADIUS := 68.0

func _ready() -> void:
	layer = 5
	_build_hud()
	_target_money = GameSys.get_money()
	_displayed_money = float(_target_money)
	_update_money_text(_target_money)
	_on_rating_changed(GameSys.get_rating_stars(), GameSys.get_satisfaction())
	_on_lights_toggled(GameSys.is_lights_on())

	GameSys.money_changed.connect(_on_money_changed)
	GameSys.rating_changed.connect(_on_rating_changed)
	GameSys.lights_toggled.connect(_on_lights_toggled)
	GameSys.combo_updated.connect(_on_combo_updated)
	GameSys.toast_requested.connect(_on_toast_requested)
	GameSys.sale_popup_requested.connect(_on_sale_popup_requested)

func bind_player(player: Node3D) -> void:
	if player != null and player.has_signal("basket_changed"):
		player.connect("basket_changed", _on_basket_changed)
		var b: Array = player.get("basket")
		_on_basket_changed(b)
		_discard_btn.pressed.connect(func() -> void:
			if is_instance_valid(player):
				player.call("discard_last_basket_item")
		)

func _process(delta: float) -> void:
	if absf(_displayed_money - float(_target_money)) > 0.4:
		_displayed_money = lerpf(_displayed_money, float(_target_money), clampf(delta * 12.0, 0.0, 1.0))
		_update_money_text(int(round(_displayed_money)))
	elif int(round(_displayed_money)) != _target_money:
		_displayed_money = float(_target_money)
		_update_money_text(_target_money)

func _build_hud() -> void:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_popups_layer = Control.new()
	_popups_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	_popups_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_popups_layer)

	# TOP-LEFT: Money + Light Switch
	var tl_v := VBoxContainer.new()
	tl_v.position = Vector2(24, 26)
	tl_v.add_theme_constant_override("separation", 10)
	tl_v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(tl_v)

	var money_card := _pill_panel(Color(0.11, 0.16, 0.24, 0.92), Color(1.0, 0.80, 0.22))
	tl_v.add_child(money_card)
	_money_lbl = Label.new()
	_money_lbl.add_theme_font_size_override("font_size", 32)
	_money_lbl.add_theme_color_override("font_color", Color(1.0, 0.92, 0.36))
	money_card.add_child(_money_lbl)

	_light_btn = _hud_btn("💡 Đèn: BẬT (L)", Color(0.20, 0.56, 0.72), Vector2(230, 52), 20)
	_light_btn.pressed.connect(func() -> void:
		AudioSys.play_sfx("ui_click")
		GameSys.set_lights_on(not GameSys.is_lights_on())
	)
	tl_v.add_child(_light_btn)

	# TOP-RIGHT: Rating Stars + Satisfaction + Pause ☰
	var tr_h := HBoxContainer.new()
	tr_h.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	tr_h.offset_left = -560
	tr_h.offset_right = -24
	tr_h.offset_top = 26
	tr_h.offset_bottom = 112
	tr_h.alignment = BoxContainer.ALIGNMENT_END
	tr_h.add_theme_constant_override("separation", 12)
	tr_h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(tr_h)

	var rating_card := _pill_panel(Color(0.11, 0.16, 0.24, 0.92), Color(0.42, 0.78, 1.0))
	tr_h.add_child(rating_card)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 2)
	rating_card.add_child(rv)

	_stars_lbl = Label.new()
	_stars_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_stars_lbl.add_theme_font_size_override("font_size", 24)
	_stars_lbl.add_theme_color_override("font_color", Color(1.0, 0.84, 0.20))
	rv.add_child(_stars_lbl)

	_sat_lbl = Label.new()
	_sat_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_sat_lbl.add_theme_font_size_override("font_size", 17)
	_sat_lbl.add_theme_color_override("font_color", Color(0.80, 0.92, 1.0))
	rv.add_child(_sat_lbl)

	var stats_btn := _hud_btn("📊", Color(0.26, 0.44, 0.70), Vector2(72, 74), 28)
	stats_btn.pressed.connect(func() -> void: stats_button_pressed.emit())
	tr_h.add_child(stats_btn)

	var pause_btn := _hud_btn("☰", Color(0.32, 0.38, 0.52), Vector2(78, 74), 32)
	pause_btn.pressed.connect(func() -> void: pause_button_pressed.emit())
	tr_h.add_child(pause_btn)

	# STREAK COMBO BADGE (Upper Center)
	_combo_panel = _pill_panel(Color(0.85, 0.26, 0.12, 0.95), Color(1.0, 0.90, 0.25))
	_combo_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_combo_panel.offset_left = -180
	_combo_panel.offset_right = 180
	_combo_panel.offset_top = 128
	_combo_panel.offset_bottom = 192
	_combo_panel.visible = false
	root.add_child(_combo_panel)

	_combo_lbl = Label.new()
	_combo_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_combo_lbl.add_theme_font_size_override("font_size", 26)
	_combo_lbl.add_theme_color_override("font_color", Color(1.0, 0.96, 0.75))
	_combo_panel.add_child(_combo_lbl)

	# TOAST NOTIFICATION BANNER
	_toast_panel = _pill_panel(Color(0.12, 0.17, 0.26, 0.95), Color(1.0, 0.80, 0.28))
	_toast_panel.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_toast_panel.offset_left = 70
	_toast_panel.offset_right = -70
	_toast_panel.offset_top = 205
	_toast_panel.offset_bottom = 272
	_toast_panel.visible = false
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_toast_panel)

	_toast_lbl = Label.new()
	_toast_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_toast_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast_lbl.add_theme_font_size_override("font_size", 22)
	_toast_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_panel.add_child(_toast_lbl)

	# BOTTOM-LEFT: Virtual Joystick + Held Basket Panel
	_joy_base = Control.new()
	_joy_base.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_joy_base.offset_left = 42
	_joy_base.offset_right = 222
	_joy_base.offset_top = -410
	_joy_base.offset_bottom = -230
	_joy_base.mouse_filter = Control.MOUSE_FILTER_STOP
	_joy_base.gui_input.connect(_on_joystick_gui_input)
	root.add_child(_joy_base)

	var joy_ring := Panel.new()
	joy_ring.set_anchors_preset(Control.PRESET_FULL_RECT)
	joy_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var jst := StyleBoxFlat.new()
	jst.bg_color = Color(0.10, 0.14, 0.22, 0.52)
	jst.border_color = Color(1.0, 1.0, 1.0, 0.42)
	jst.set_border_width_all(3)
	jst.set_corner_radius_all(90)
	joy_ring.add_theme_stylebox_override("panel", jst)
	_joy_base.add_child(joy_ring)

	_joy_knob = Panel.new()
	_joy_knob.size = Vector2(72, 72)
	_joy_knob.position = Vector2(54, 54)
	_joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var kst := StyleBoxFlat.new()
	kst.bg_color = Color(1.0, 0.80, 0.24, 0.88)
	kst.set_corner_radius_all(36)
	_joy_knob.add_theme_stylebox_override("panel", kst)
	_joy_base.add_child(_joy_knob)

	var basket_card := _pill_panel(Color(0.11, 0.16, 0.24, 0.94), Color(1.0, 0.72, 0.22))
	basket_card.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	basket_card.offset_left = 24
	basket_card.offset_right = 610
	basket_card.offset_top = -205
	basket_card.offset_bottom = -28
	root.add_child(basket_card)

	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 6)
	basket_card.add_child(bv)

	var bh := HBoxContainer.new()
	bh.add_theme_constant_override("separation", 10)
	bv.add_child(bh)

	var btitle := Label.new()
	btitle.text = "🧺 Giỏ đang cầm:"
	btitle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btitle.add_theme_font_size_override("font_size", 20)
	btitle.add_theme_color_override("font_color", Color(1.0, 0.88, 0.44))
	bh.add_child(btitle)

	_discard_btn = _hud_btn("↩ Trả kệ (Q)", Color(0.65, 0.28, 0.28), Vector2(142, 40), 16)
	_discard_btn.visible = false
	bh.add_child(_discard_btn)

	_basket_items_hbox = HBoxContainer.new()
	_basket_items_hbox.add_theme_constant_override("separation", 10)
	bv.add_child(_basket_items_hbox)

	_basket_empty_lbl = Label.new()
	_basket_empty_lbl.text = "Trống — Chạm kệ hoặc bấm E để lấy đồ"
	_basket_empty_lbl.add_theme_font_size_override("font_size", 18)
	_basket_empty_lbl.add_theme_color_override("font_color", Color(0.68, 0.76, 0.86))
	bv.add_child(_basket_empty_lbl)

	# BOTTOM-RIGHT: Interact + Shop + Decor + PC hint
	var br_v := VBoxContainer.new()
	br_v.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	br_v.offset_left = -430
	br_v.offset_right = -24
	br_v.offset_top = -310
	br_v.offset_bottom = -28
	br_v.alignment = BoxContainer.ALIGNMENT_END
	br_v.add_theme_constant_override("separation", 12)
	br_v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(br_v)

	var act_btn := _hud_btn("🖐 Lấy / Bán hàng (E / Space)", Color(0.95, 0.55, 0.14), Vector2(0, 72), 22)
	act_btn.pressed.connect(func() -> void: interact_button_pressed.emit())
	br_v.add_child(act_btn)

	var row_btns := HBoxContainer.new()
	row_btns.add_theme_constant_override("separation", 12)
	br_v.add_child(row_btns)

	var shop_btn := _hud_btn("🛒 Shop (B)", Color(0.18, 0.68, 0.40), Vector2(196, 74), 23)
	shop_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_btn.pressed.connect(func() -> void: shop_button_pressed.emit())
	row_btns.add_child(shop_btn)

	var decor_btn := _hud_btn("🎨 Trang trí (V)", Color(0.54, 0.32, 0.78), Vector2(196, 74), 22)
	decor_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	decor_btn.pressed.connect(func() -> void: decor_button_pressed.emit())
	row_btns.add_child(decor_btn)

	var pc_hint := Label.new()
	pc_hint.text = "💻 PC: WASD/Mũi tên chạy • Click kệ/quầy tự lấy & bán • F11 Toàn màn hình"
	pc_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pc_hint.add_theme_font_size_override("font_size", 15)
	pc_hint.add_theme_color_override("font_color", Color(0.88, 0.94, 1.0, 0.88))
	br_v.add_child(pc_hint)

func _on_joystick_gui_input(event: InputEvent) -> void:
	var center := _joy_base.size * 0.5
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_joy_touch_idx = st.index
			_update_joy_from_local(st.position - center)
		elif st.index == _joy_touch_idx:
			_reset_joystick()
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if sd.index == _joy_touch_idx:
			_update_joy_from_local(sd.position - center)
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_joy_mouse_dragging = true
				_update_joy_from_local(mb.position - center)
			else:
				_reset_joystick()
	elif event is InputEventMouseMotion and _joy_mouse_dragging:
		_update_joy_from_local((event as InputEventMouseMotion).position - center)

func _update_joy_from_local(delta_vec: Vector2) -> void:
	var clamped := delta_vec.limit_length(JOY_RADIUS)
	_joy_knob.position = (_joy_base.size * 0.5) + clamped - (_joy_knob.size * 0.5)
	joystick_updated.emit(clamped / JOY_RADIUS)

func _reset_joystick() -> void:
	_joy_touch_idx = -1
	_joy_mouse_dragging = false
	_joy_knob.position = (_joy_base.size - _joy_knob.size) * 0.5
	joystick_updated.emit(Vector2.ZERO)

func _update_money_text(val: int) -> void:
	if _money_lbl != null:
		_money_lbl.text = "💰 %dđ" % val

func _on_money_changed(new_money: int, delta_amt: int) -> void:
	_target_money = new_money
	if delta_amt != 0:
		var float_lbl := Label.new()
		float_lbl.text = ("+%dđ" % delta_amt) if delta_amt > 0 else ("%dđ" % delta_amt)
		float_lbl.add_theme_font_size_override("font_size", 26)
		float_lbl.add_theme_color_override("font_color", Color(0.38, 1.0, 0.52) if delta_amt > 0 else Color(1.0, 0.45, 0.45))
		float_lbl.position = Vector2(215, 34)
		_popups_layer.add_child(float_lbl)
		var tw := create_tween()
		tw.set_parallel(true)
		tw.tween_property(float_lbl, "position:y", 4.0, 0.75)
		tw.tween_property(float_lbl, "modulate:a", 0.0, 0.75)
		tw.chain().tween_callback(float_lbl.queue_free)

func _on_rating_changed(stars: float, sat: float) -> void:
	var full := int(round(stars))
	var star_str := ""
	for i in range(5):
		star_str += "★" if i < full else "☆"
	_stars_lbl.text = "%s  %.1f" % [star_str, stars]
	_sat_lbl.text = "Hài lòng: %d%% • Cấp %d" % [int(round(sat)), GameSys.get_wave_level()]

func _on_lights_toggled(is_on: bool) -> void:
	if _light_btn != null:
		_light_btn.text = "💡 Đèn: BẬT (L)" if is_on else "🌑 Đèn: TẮT (L)"

func _on_basket_changed(items: Array) -> void:
	for c in _basket_items_hbox.get_children():
		c.queue_free()

	if items.is_empty():
		_basket_empty_lbl.visible = true
		_discard_btn.visible = false
		return

	_basket_empty_lbl.visible = false
	_discard_btn.visible = true

	var grouped: Dictionary = {}
	for fid in items:
		var s := String(fid)
		grouped[s] = int(grouped.get(s, 0)) + 1

	for fid in grouped.keys():
		var chip := HBoxContainer.new()
		chip.add_theme_constant_override("separation", 4)
		var ic := TextureRect.new()
		ic.texture = FoodDB.get_food_icon(String(fid))
		ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.custom_minimum_size = Vector2(48, 48)
		chip.add_child(ic)

		var ql := Label.new()
		ql.text = "x%d" % int(grouped[fid])
		ql.add_theme_font_size_override("font_size", 22)
		ql.add_theme_color_override("font_color", Color.WHITE)
		chip.add_child(ql)
		_basket_items_hbox.add_child(chip)

func _on_combo_updated(streak: int, is_bonus: bool) -> void:
	if streak < 2:
		_combo_panel.visible = false
		return
	_combo_panel.visible = true
	if is_bonus:
		_combo_lbl.text = "🔥 x%d COMBO! (Thưởng x1.5 tiền!)" % streak
	else:
		_combo_lbl.text = "🔥 x%d combo liên tiếp!" % streak
	_combo_panel.scale = Vector2(1.15, 1.15)
	var tw := create_tween()
	tw.tween_property(_combo_panel, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK)

func _on_toast_requested(msg: String, kind: String) -> void:
	_toast_lbl.text = msg
	var col := Color(0.95, 0.97, 1.0)
	if kind == "vip":
		col = Color(1.0, 0.88, 0.30)
	elif kind == "warn":
		col = Color(1.0, 0.68, 0.28)
	elif kind == "error":
		col = Color(1.0, 0.42, 0.42)
	_toast_lbl.add_theme_color_override("font_color", col)
	_toast_panel.visible = true
	_toast_panel.modulate.a = 1.0
	if _toast_tween != null and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_interval(2.8)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.45)
	_toast_tween.tween_callback(func() -> void: _toast_panel.visible = false)

func _on_sale_popup_requested(amount: int, world_pos: Vector3, bonus_text: String) -> void:
	var spawn_pos := Vector2(540, 860)
	var cam := get_viewport().get_camera_3d()
	if cam != null and not cam.is_position_behind(world_pos):
		spawn_pos = cam.unproject_position(world_pos)

	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.position = spawn_pos - Vector2(140, 30)
	box.custom_minimum_size = Vector2(280, 0)
	_popups_layer.add_child(box)

	var main_lbl := Label.new()
	main_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_lbl.text = "+%dđ" % amount
	main_lbl.add_theme_font_size_override("font_size", 44)
	main_lbl.add_theme_color_override("font_color", Color(0.35, 1.0, 0.48))
	main_lbl.add_theme_color_override("font_outline_color", Color(0.06, 0.12, 0.08))
	main_lbl.add_theme_constant_override("outline_size", 10)
	box.add_child(main_lbl)

	if bonus_text != "":
		var sub_lbl := Label.new()
		sub_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		sub_lbl.text = bonus_text
		sub_lbl.add_theme_font_size_override("font_size", 22)
		sub_lbl.add_theme_color_override("font_color", Color(1.0, 0.88, 0.28))
		sub_lbl.add_theme_color_override("font_outline_color", Color(0.1, 0.08, 0.05))
		sub_lbl.add_theme_constant_override("outline_size", 7)
		box.add_child(sub_lbl)

	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(box, "position:y", box.position.y - 115.0, 1.15).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(box, "modulate:a", 0.0, 1.15).set_delay(0.25)
	tw.chain().tween_callback(box.queue_free)

func _pill_panel(bg: Color, border: Color) -> PanelContainer:
	var p := PanelContainer.new()
	var st := StyleBoxFlat.new()
	st.bg_color = bg
	st.border_color = border
	st.set_border_width_all(3)
	st.set_corner_radius_all(18)
	st.content_margin_left = 16
	st.content_margin_right = 16
	st.content_margin_top = 10
	st.content_margin_bottom = 10
	p.add_theme_stylebox_override("panel", st)
	return p

func _hud_btn(txt: String, col: Color, min_sz: Vector2, fsize: int) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = min_sz
	b.add_theme_font_size_override("font_size", fsize)
	var st := StyleBoxFlat.new()
	st.bg_color = col
	st.border_color = col.lightened(0.28)
	st.set_border_width_all(2)
	st.set_corner_radius_all(16)
	var sth := st.duplicate() as StyleBoxFlat
	sth.bg_color = col.lightened(0.14)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", sth)
	b.add_theme_stylebox_override("pressed", st)
	return b
