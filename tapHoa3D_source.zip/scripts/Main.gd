extends Node

var _current_view: Node = null

func _ready() -> void:
	show_splash()

func show_splash() -> void:
	_clear_current_view()
	var splash_scene := load("res://scenes/SplashScreen.tscn") as PackedScene
	if splash_scene != null:
		var sp := splash_scene.instantiate()
		add_child(sp)
		sp.connect("start_game_requested", show_game_world)
		_current_view = sp

func show_game_world() -> void:
	_clear_current_view()
	var world_scene := load("res://scenes/GameWorld.tscn") as PackedScene
	if world_scene != null:
		var gw := world_scene.instantiate()
		add_child(gw)
		gw.connect("exit_to_splash", show_splash)
		_current_view = gw

func _clear_current_view() -> void:
	if _current_view != null and is_instance_valid(_current_view):
		_current_view.queue_free()
		_current_view = null
