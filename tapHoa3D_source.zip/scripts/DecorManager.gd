extends CanvasLayer

signal decor_mode_closed()

var is_active: bool = false
var decor_world_root: Node3D = null
var _spawned_nodes: Dictionary = {} # uid -> Node3D
var _selected_uid: int = -1
var _dragging: bool = false
var _selection_ring: MeshInstance3D

var _bar_panel: PanelContainer
var _title_label: Label
var _rotate_btn: Button
var _delete_btn: Button
var _done_btn: Button

func _ready() -> void:
	layer = 9
	visible = false
	_build_overlay_ui()
	GameSys.enter_decor_place_mode.connect(_on_buy_and_place_decor)

func bind_world_root(root_3d: Node3D) -> void:
	decor_world_root = root_3d
	_create_selection_ring()
	rebuild_all_placed_decor()

func _create_selection_ring() -> void:
	if decor_world_root == null:
		return
	_selection_ring = MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.72
	cyl.bottom_radius = 0.72
	cyl.height = 0.03
	_selection_ring.mesh = cyl
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.20, 0.95, 1.0, 0.65)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_selection_ring.material_override = mat
	_selection_ring.visible = false
	decor_world_root.add_child(_selection_ring)

func _build_overlay_ui() -> void:
	var root_ctrl := Control.new()
	root_ctrl.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_ctrl.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(root_ctrl)

	var top_banner := PanelContainer.new()
	top_banner.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top_banner.offset_left = 40
	top_banner.offset_right = -40
	top_banner.offset_top = 150
	top_banner.offset_bottom = 225
	var top_style := StyleBoxFlat.new()
	top_style.bg_color = Color(0.10, 0.14, 0.22, 0.92)
	top_style.border_color = Color(0.25, 0.88, 1.0)
	top_style.set_border_width_all(3)
	top_style.set_corner_radius_all(18)
	top_banner.add_theme_stylebox_override("panel", top_style)
	root_ctrl.add_child(top_banner)

	_title_label = Label.new()
	_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_title_label.add_theme_font_size_override("font_size", 24)
	_title_label.text = "🎨 CHẾ ĐỘ TRANG TRÍ: Chạm & kéo đồ vật trên sàn để đặt vị trí"
	top_banner.add_child(_title_label)

	_bar_panel = PanelContainer.new()
	_bar_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	_bar_panel.offset_left = 36
	_bar_panel.offset_right = -36
	_bar_panel.offset_top = -170
	_bar_panel.offset_bottom = -36
	var bar_style := StyleBoxFlat.new()
	bar_style.bg_color = Color(0.12, 0.15, 0.22, 0.95)
	bar_style.border_color = Color(1.0, 0.78, 0.25)
	bar_style.set_border_width_all(3)
	bar_style.set_corner_radius_all(22)
	bar_style.content_margin_left = 18
	bar_style.content_margin_right = 18
	bar_style.content_margin_top = 14
	bar_style.content_margin_bottom = 14
	_bar_panel.add_theme_stylebox_override("panel", bar_style)
	root_ctrl.add_child(_bar_panel)

	var hbox := HBoxContainer.new()
	hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox.add_theme_constant_override("separation", 18)
	_bar_panel.add_child(hbox)

	_rotate_btn = _make_action_btn("↻ Xoay (R)", Color(0.18, 0.55, 0.88))
	_rotate_btn.pressed.connect(rotate_selected)
	hbox.add_child(_rotate_btn)

	_delete_btn = _make_action_btn("🗑 Xoá hoàn 50% (X)", Color(0.85, 0.26, 0.26))
	_delete_btn.pressed.connect(delete_selected_with_refund)
	hbox.add_child(_delete_btn)

	_done_btn = _make_action_btn("✓ Hoàn tất", Color(0.22, 0.72, 0.36))
	_done_btn.pressed.connect(close_decor_mode)
	hbox.add_child(_done_btn)

func _make_action_btn(txt: String, col: Color) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = Vector2(280, 84)
	b.add_theme_font_size_override("font_size", 24)
	var st := StyleBoxFlat.new()
	st.bg_color = col
	st.set_corner_radius_all(16)
	var st_h := st.duplicate() as StyleBoxFlat
	st_h.bg_color = col.lightened(0.14)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st_h)
	b.add_theme_stylebox_override("pressed", st)
	return b

func rebuild_all_placed_decor() -> void:
	if decor_world_root == null:
		return
	for uid in _spawned_nodes.keys():
		var n: Node3D = _spawned_nodes[uid]
		if is_instance_valid(n):
			n.queue_free()
	_spawned_nodes.clear()

	var placed: Array = SaveSys.data.get("placed_decor", [])
	for entry in placed:
		if entry is Dictionary:
			_spawn_decor_instance(entry)
	GameSys.decor_updated.emit()

func _spawn_decor_instance(entry: Dictionary) -> Node3D:
	if decor_world_root == null:
		return null
	var uid := int(entry.get("uid", 1))
	var did := String(entry.get("id", "green_plant"))
	var holder := _create_decor_3d_mesh(did)
	holder.position = Vector3(
		float(entry.get("x", 3.8)),
		float(entry.get("y", 0.0)),
		float(entry.get("z", 1.5))
	)
	holder.rotation_degrees.y = float(entry.get("rot_y", 0.0))
	holder.set_meta("decor_uid", uid)
	holder.set_meta("decor_id", did)
	decor_world_root.add_child(holder)
	_spawned_nodes[uid] = holder
	return holder

func _create_decor_3d_mesh(decor_id: String) -> Node3D:
	var root := Node3D.new()
	match decor_id:
		"green_plant":
			var pot := MeshInstance3D.new()
			var pc := CylinderMesh.new()
			pc.top_radius = 0.28
			pc.bottom_radius = 0.20
			pc.height = 0.42
			pot.mesh = pc
			pot.position = Vector3(0, 0.21, 0)
			pot.material_override = _mat(Color(0.76, 0.44, 0.28))
			root.add_child(pot)
			for i in range(5):
				var leaf := MeshInstance3D.new()
				var ls := SphereMesh.new()
				ls.radius = 0.24
				ls.height = 0.52
				leaf.mesh = ls
				var ang := float(i) * TAU / 5.0
				leaf.position = Vector3(cos(ang) * 0.18, 0.68 + (i % 2) * 0.14, sin(ang) * 0.18)
				leaf.material_override = _mat(Color(0.22, 0.68, 0.30))
				root.add_child(leaf)
		"anime_poster":
			var stand := MeshInstance3D.new()
			var sb := BoxMesh.new()
			sb.size = Vector3(0.95, 1.45, 0.08)
			stand.mesh = sb
			stand.position = Vector3(0, 0.95, 0)
			var pmat := StandardMaterial3D.new()
			if ResourceLoader.exists("res://assets/textures/world/anime_poster_tex.png"):
				pmat.albedo_texture = load("res://assets/textures/world/anime_poster_tex.png") as Texture2D
			else:
				pmat.albedo_color = Color(1.0, 0.48, 0.72)
			stand.material_override = pmat
			root.add_child(stand)
		"flower_rug":
			var rug := MeshInstance3D.new()
			var rc := CylinderMesh.new()
			rc.top_radius = 0.95
			rc.bottom_radius = 0.95
			rc.height = 0.025
			rug.mesh = rc
			rug.position = Vector3(0, 0.015, 0)
			var rmat := StandardMaterial3D.new()
			if ResourceLoader.exists("res://assets/textures/world/flower_rug_tex.png"):
				rmat.albedo_texture = load("res://assets/textures/world/flower_rug_tex.png") as Texture2D
				rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			else:
				rmat.albedo_color = Color(1.0, 0.78, 0.22)
			rug.material_override = rmat
			root.add_child(rug)
		"neon_light":
			var pole := MeshInstance3D.new()
			var pb := BoxMesh.new()
			pb.size = Vector3(0.12, 1.5, 0.12)
			pole.mesh = pb
			pole.position = Vector3(0, 0.75, 0)
			pole.material_override = _mat(Color(0.2, 0.22, 0.28))
			root.add_child(pole)
			var ring := MeshInstance3D.new()
			var tb := TorusMesh.new()
			tb.inner_radius = 0.30
			tb.outer_radius = 0.42
			ring.mesh = tb
			ring.position = Vector3(0, 1.55, 0)
			ring.rotation_degrees = Vector3(90, 0, 0)
			var nmat := _mat(Color(0.0, 0.92, 1.0))
			nmat.emission_enabled = true
			nmat.emission = Color(0.0, 0.85, 1.0)
			nmat.emission_energy_multiplier = 2.0
			ring.material_override = nmat
			root.add_child(ring)
			var omni := OmniLight3D.new()
			omni.light_color = Color(0.2, 0.9, 1.0)
			omni.light_energy = 1.1
			omni.omni_range = 4.2
			omni.position = Vector3(0, 1.55, 0.3)
			root.add_child(omni)
		"music_speaker":
			var spk := MeshInstance3D.new()
			if ResourceLoader.exists("res://assets/models/speaker_box.obj"):
				spk.mesh = load("res://assets/models/speaker_box.obj") as Mesh
			else:
				var bm := BoxMesh.new()
				bm.size = Vector3(0.55, 1.15, 0.48)
				spk.mesh = bm
				spk.position = Vector3(0, 0.58, 0)
			spk.material_override = _mat(Color(0.28, 0.20, 0.52))
			root.add_child(spk)
			for cy in [0.42, 0.84]:
				var cone := MeshInstance3D.new()
				var cc := CylinderMesh.new()
				cc.top_radius = 0.16
				cc.bottom_radius = 0.16
				cc.height = 0.06
				cone.mesh = cc
				cone.rotation_degrees = Vector3(90, 0, 0)
				cone.position = Vector3(0, float(cy), 0.25)
				var cmat := _mat(Color(0.0, 0.95, 0.55))
				cmat.emission_enabled = true
				cmat.emission = Color(0.0, 0.75, 0.42)
				cone.material_override = cmat
				root.add_child(cone)
		"modern_pos":
			var ped := MeshInstance3D.new()
			var pb := BoxMesh.new()
			pb.size = Vector3(0.55, 0.95, 0.48)
			ped.mesh = pb
			ped.position = Vector3(0, 0.48, 0)
			ped.material_override = _mat(Color(0.22, 0.26, 0.30))
			root.add_child(ped)
			var scr := MeshInstance3D.new()
			var sb := BoxMesh.new()
			sb.size = Vector3(0.50, 0.38, 0.08)
			scr.mesh = sb
			scr.position = Vector3(0, 1.14, 0)
			var smat := _mat(Color(0.0, 0.86, 0.96))
			smat.emission_enabled = true
			smat.emission = Color(0.0, 0.75, 0.90)
			scr.material_override = smat
			root.add_child(scr)
		"led_sign":
			var board := MeshInstance3D.new()
			var bb := BoxMesh.new()
			bb.size = Vector3(1.15, 0.65, 0.14)
			board.mesh = bb
			board.position = Vector3(0, 1.25, 0)
			var bmat := _mat(Color(1.0, 0.28, 0.36))
			bmat.emission_enabled = true
			bmat.emission = Color(0.95, 0.20, 0.30)
			board.material_override = bmat
			root.add_child(board)
			var post := MeshInstance3D.new()
			var post_b := BoxMesh.new()
			post_b.size = Vector3(0.14, 0.95, 0.14)
			post.mesh = post_b
			post.position = Vector3(0, 0.48, 0)
			post.material_override = _mat(Color(0.25, 0.25, 0.3))
			root.add_child(post)
		_: # display_cabinet
			var cab := MeshInstance3D.new()
			if ResourceLoader.exists("res://assets/models/display_cabinet.obj"):
				cab.mesh = load("res://assets/models/display_cabinet.obj") as Mesh
			else:
				var bm := BoxMesh.new()
				bm.size = Vector3(1.3, 1.85, 0.65)
				cab.mesh = bm
				cab.position = Vector3(0, 0.92, 0)
			var gmat := _mat(Color(0.55, 0.86, 0.98))
			gmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			gmat.albedo_color.a = 0.72
			cab.material_override = gmat
			root.add_child(cab)
	return root

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.55
	return m

func _on_buy_and_place_decor(decor_id: String) -> void:
	var d := FoodDB.get_decor(decor_id)
	if d.is_empty():
		return
	var price := int(d.get("price", 300))
	if not GameSys.spend_money(price):
		GameSys.show_toast("Chưa đủ %dđ để mua %s!" % [price, String(d.get("name", ""))], "warn")
		return

	var uid := int(SaveSys.data.get("next_decor_uid", 1))
	SaveSys.data["next_decor_uid"] = uid + 1
	var entry := {
		"uid": uid,
		"id": decor_id,
		"x": randf_range(3.2, 4.3),
		"y": 0.0,
		"z": randf_range(1.2, 3.2),
		"rot_y": 0.0
	}
	var placed: Array = SaveSys.data.get("placed_decor", [])
	placed.append(entry)
	SaveSys.data["placed_decor"] = placed
	SaveSys.save_game()

	_spawn_decor_instance(entry)
	AudioSys.play_sfx("coin_drop")
	if bool(d.get("unlocks_bgm", false)):
		AudioSys.play_bgm(1)
		GameSys.show_toast("🎵 Đã mở khoá nhạc nền sôi động mới nhờ Loa phát nhạc!", "vip")
	GameSys.decor_updated.emit()
	open_decor_mode(uid)

func open_decor_mode(select_uid: int = -1) -> void:
	is_active = true
	visible = true
	if select_uid > 0 and _spawned_nodes.has(select_uid):
		_select_uid(select_uid)
	elif not _spawned_nodes.is_empty():
		_select_uid(int(_spawned_nodes.keys()[0]))
	else:
		_select_uid(-1)
	_set_player_blocked(true)

func close_decor_mode() -> void:
	if not is_active:
		return
	is_active = false
	visible = false
	_dragging = false
	if _selection_ring != null:
		_selection_ring.visible = false
	SaveSys.save_game()
	_set_player_blocked(false)
	AudioSys.play_sfx("ui_click")
	decor_mode_closed.emit()

func _set_player_blocked(blocked: bool) -> void:
	for p in get_tree().get_nodes_in_group("player"):
		p.set("ui_blocking_input", blocked)

func _select_uid(uid: int) -> void:
	_selected_uid = uid
	if _selected_uid > 0 and _spawned_nodes.has(_selected_uid):
		var node: Node3D = _spawned_nodes[_selected_uid]
		var did := String(node.get_meta("decor_id", ""))
		var d := FoodDB.get_decor(did)
		var refund := int(int(d.get("price", 200)) * 0.5)
		_title_label.text = "🎨 Đang chọn: %s — Kéo trên sàn để di chuyển" % String(d.get("name", did))
		_delete_btn.text = "🗑 Bán (+%dđ)" % refund
		_rotate_btn.disabled = false
		_delete_btn.disabled = false
		if _selection_ring != null:
			_selection_ring.visible = true
			_selection_ring.global_position = Vector3(node.global_position.x, 0.03, node.global_position.z)
	else:
		_title_label.text = "🎨 Chưa có đồ trang trí nào! Hãy mua trong Shop -> Tab Trang Trí."
		_rotate_btn.disabled = true
		_delete_btn.disabled = true
		if _selection_ring != null:
			_selection_ring.visible = false

func rotate_selected() -> void:
	if _selected_uid <= 0 or not _spawned_nodes.has(_selected_uid):
		return
	var node: Node3D = _spawned_nodes[_selected_uid]
	node.rotation_degrees.y = fmod(node.rotation_degrees.y + 45.0, 360.0)
	_sync_node_to_save(_selected_uid, node)
	AudioSys.play_sfx("ui_click")

func delete_selected_with_refund() -> void:
	if _selected_uid <= 0 or not _spawned_nodes.has(_selected_uid):
		return
	var node: Node3D = _spawned_nodes[_selected_uid]
	var did := String(node.get_meta("decor_id", ""))
	var d := FoodDB.get_decor(did)
	var refund := int(int(d.get("price", 200)) * 0.5)

	var placed: Array = SaveSys.data.get("placed_decor", [])
	for i in range(placed.size() - 1, -1, -1):
		if placed[i] is Dictionary and int(placed[i].get("uid", -1)) == _selected_uid:
			placed.remove_at(i)
			break
	SaveSys.data["placed_decor"] = placed
	SaveSys.save_game()

	node.queue_free()
	_spawned_nodes.erase(_selected_uid)
	GameSys.add_money(refund)
	AudioSys.play_sfx("coin_drop")
	GameSys.show_toast("Đã xoá %s & hoàn +%dđ (50%%)!" % [String(d.get("name", did)), refund], "info")
	GameSys.decor_updated.emit()
	if not AudioSys.is_speaker_unlocked() and AudioSys.current_bgm_index != 0:
		AudioSys.play_bgm(0)

	if not _spawned_nodes.is_empty():
		_select_uid(int(_spawned_nodes.keys()[0]))
	else:
		_select_uid(-1)

func _sync_node_to_save(uid: int, node: Node3D) -> void:
	var placed: Array = SaveSys.data.get("placed_decor", [])
	for entry in placed:
		if entry is Dictionary and int(entry.get("uid", -1)) == uid:
			entry["x"] = node.position.x
			entry["y"] = node.position.y
			entry["z"] = node.position.z
			entry["rot_y"] = node.rotation_degrees.y
			break

func _unhandled_input(event: InputEvent) -> void:
	if not is_active:
		return

	if event is InputEventKey and event.pressed and not event.echo:
		var ke := event as InputEventKey
		if ke.keycode == KEY_R:
			rotate_selected()
			get_viewport().set_input_as_handled()
			return
		elif ke.keycode == KEY_X or ke.keycode == KEY_DELETE:
			delete_selected_with_refund()
			get_viewport().set_input_as_handled()
			return
		elif ke.keycode == KEY_ESCAPE:
			close_decor_mode()
			get_viewport().set_input_as_handled()
			return

	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_handle_pointer_down(mb.position)
			else:
				_dragging = false
				SaveSys.save_game()
	elif event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_handle_pointer_down(st.position)
		else:
			_dragging = false
			SaveSys.save_game()
	elif event is InputEventMouseMotion and _dragging:
		_handle_pointer_drag((event as InputEventMouseMotion).position)
	elif event is InputEventScreenDrag and _dragging:
		_handle_pointer_drag((event as InputEventScreenDrag).position)

func _screen_to_floor(screen_pos: Vector2) -> Variant:
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return null
	var origin := cam.project_ray_origin(screen_pos)
	var normal := cam.project_ray_normal(screen_pos)
	return Plane(Vector3.UP, 0.0).intersects_ray(origin, normal)

func _handle_pointer_down(screen_pos: Vector2) -> void:
	var hit: Variant = _screen_to_floor(screen_pos)
	if hit == null:
		return
	var world_pt := hit as Vector3
	var best_uid := -1
	var best_dist := 1.45
	for uid in _spawned_nodes.keys():
		var n: Node3D = _spawned_nodes[uid]
		if is_instance_valid(n):
			var d := Vector2(n.global_position.x, n.global_position.z).distance_to(Vector2(world_pt.x, world_pt.z))
			if d < best_dist:
				best_dist = d
				best_uid = int(uid)
	if best_uid > 0:
		_select_uid(best_uid)
		_dragging = true
	elif _selected_uid > 0 and _spawned_nodes.has(_selected_uid):
		_dragging = true
		_handle_pointer_drag(screen_pos)

func _handle_pointer_drag(screen_pos: Vector2) -> void:
	if _selected_uid <= 0 or not _spawned_nodes.has(_selected_uid):
		return
	var hit: Variant = _screen_to_floor(screen_pos)
	if hit == null:
		return
	var pt := hit as Vector3
	var clamped := Vector3(clampf(pt.x, -4.7, 4.7), 0.0, clampf(pt.z, -5.2, 5.5))
	var node: Node3D = _spawned_nodes[_selected_uid]
	node.position = clamped
	if _selection_ring != null:
		_selection_ring.global_position = Vector3(clamped.x, 0.03, clamped.z)
	_sync_node_to_save(_selected_uid, node)
