extends CanvasLayer

signal return_to_splash_requested()

var is_open: bool = false
var _sfx_btn: Button
var _bgm_btn: Button
var _track_btn: Button
var _store_name_edit: LineEdit
var _confirm_overlay: Control

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 12
	visible = false
	_build_pause_ui()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if is_open:
			resume_game()
		else:
			open_pause_menu()

func open_pause_menu() -> void:
	if is_open:
		return
	is_open = true
	visible = true
	_confirm_overlay.visible = false
	_store_name_edit.text = GameSys.get_store_name()
	_refresh_toggles()
	get_tree().paused = true
	AudioSys.play_sfx("ui_click")

func resume_game() -> void:
	if not is_open:
		return
	GameSys.set_store_name(_store_name_edit.text)
	is_open = false
	visible = false
	get_tree().paused = false
	AudioSys.play_sfx("ui_click")

func _unhandled_input(event: InputEvent) -> void:
	if not is_open:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if (event as InputEventKey).keycode == KEY_ESCAPE:
			resume_game()
			get_viewport().set_input_as_handled()

func _build_pause_ui() -> void:
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.03, 0.05, 0.09, 0.78)
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(760, 0)
	var st := StyleBoxFlat.new()
	st.bg_color = Color(0.13, 0.17, 0.25, 0.98)
	st.border_color = Color(1.0, 0.80, 0.26)
	st.set_border_width_all(4)
	st.set_corner_radius_all(28)
	st.content_margin_left = 36
	st.content_margin_right = 36
	st.content_margin_top = 32
	st.content_margin_bottom = 32
	card.add_theme_stylebox_override("panel", st)
	center.add_child(card)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 18)
	card.add_child(v)

	var title := Label.new()
	title.text = "⏸ TẠM DỪNG CỬA TIỆM"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	title.add_theme_color_override("font_color", Color(1.0, 0.90, 0.38))
	v.add_child(title)

	# Store Name input
	var name_lbl := Label.new()
	name_lbl.text = "Tên bảng LED cửa hàng:"
	name_lbl.add_theme_font_size_override("font_size", 22)
	name_lbl.add_theme_color_override("font_color", Color(0.84, 0.92, 1.0))
	v.add_child(name_lbl)

	var name_row := HBoxContainer.new()
	name_row.add_theme_constant_override("separation", 10)
	v.add_child(name_row)

	_store_name_edit = LineEdit.new()
	_store_name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_store_name_edit.custom_minimum_size = Vector2(0, 62)
	_store_name_edit.max_length = 26
	_store_name_edit.placeholder_text = "Nhập tên tiệm của bạn..."
	_store_name_edit.add_theme_font_size_override("font_size", 24)
	name_row.add_child(_store_name_edit)

	var save_name_btn := _btn("Đổi tên", Color(0.20, 0.62, 0.88), Vector2(150, 62))
	save_name_btn.pressed.connect(func() -> void:
		GameSys.set_store_name(_store_name_edit.text)
		AudioSys.play_sfx("sell_ting")
		GameSys.show_toast("Đã cập nhật bảng LED: " + GameSys.get_store_name(), "info")
	)
	name_row.add_child(save_name_btn)

	var resume_btn := _btn("▶ Tiếp tục bán hàng", Color(0.20, 0.72, 0.38), Vector2(0, 74))
	resume_btn.pressed.connect(resume_game)
	v.add_child(resume_btn)

	_sfx_btn = _btn("🔊 Âm thanh (SFX): BẬT", Color(0.24, 0.42, 0.68), Vector2(0, 66))
	_sfx_btn.pressed.connect(func() -> void:
		AudioSys.set_sound_enabled(not AudioSys.sound_enabled)
		AudioSys.play_sfx("ui_click")
		_refresh_toggles()
	)
	v.add_child(_sfx_btn)

	_bgm_btn = _btn("🎵 Nhạc nền (BGM): BẬT", Color(0.24, 0.42, 0.68), Vector2(0, 66))
	_bgm_btn.pressed.connect(func() -> void:
		AudioSys.set_music_enabled(not AudioSys.music_enabled)
		AudioSys.play_sfx("ui_click")
		_refresh_toggles()
	)
	v.add_child(_bgm_btn)

	_track_btn = _btn("📻 Đổi kênh nhạc Loa Hi-Fi", Color(0.45, 0.30, 0.72), Vector2(0, 64))
	_track_btn.pressed.connect(func() -> void:
		AudioSys.toggle_bgm_track()
		AudioSys.play_sfx("ui_click")
		_refresh_toggles()
	)
	v.add_child(_track_btn)

	var home_btn := _btn("🏠 Về màn hình chính", Color(0.75, 0.50, 0.16), Vector2(0, 66))
	home_btn.pressed.connect(func() -> void:
		GameSys.set_store_name(_store_name_edit.text)
		SaveSys.save_game()
		is_open = false
		visible = false
		get_tree().paused = false
		AudioSys.play_sfx("ui_click")
		return_to_splash_requested.emit()
	)
	v.add_child(home_btn)

	var quit_btn := _btn("🚪 Thoát game", Color(0.82, 0.24, 0.26), Vector2(0, 66))
	quit_btn.pressed.connect(func() -> void:
		AudioSys.play_sfx("ui_click")
		_confirm_overlay.visible = true
	)
	v.add_child(quit_btn)

	# Confirm Quit Dialog
	_confirm_overlay = Control.new()
	_confirm_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_confirm_overlay.visible = false
	add_child(_confirm_overlay)

	var cdim := ColorRect.new()
	cdim.set_anchors_preset(Control.PRESET_FULL_RECT)
	cdim.color = Color(0, 0, 0, 0.72)
	_confirm_overlay.add_child(cdim)

	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	_confirm_overlay.add_child(cc)

	var cbox := PanelContainer.new()
	cbox.custom_minimum_size = Vector2(640, 0)
	cbox.add_theme_stylebox_override("panel", st)
	cc.add_child(cbox)

	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 22)
	cbox.add_child(cv)

	var clbl := Label.new()
	clbl.text = "Lưu dữ liệu cửa hàng và thoát game?"
	clbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	clbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	clbl.add_theme_font_size_override("font_size", 28)
	cv.add_child(clbl)

	var crow := HBoxContainer.new()
	crow.alignment = BoxContainer.ALIGNMENT_CENTER
	crow.add_theme_constant_override("separation", 20)
	cv.add_child(crow)

	var cancel_b := _btn("Huỷ", Color(0.32, 0.38, 0.48), Vector2(220, 66))
	cancel_b.pressed.connect(func() -> void:
		_confirm_overlay.visible = false
	)
	crow.add_child(cancel_b)

	var yes_b := _btn("Lưu & Thoát", Color(0.84, 0.24, 0.26), Vector2(240, 66))
	yes_b.pressed.connect(func() -> void:
		GameSys.set_store_name(_store_name_edit.text)
		SaveSys.save_game()
		get_tree().paused = false
		get_tree().quit()
	)
	crow.add_child(yes_b)

func _refresh_toggles() -> void:
	_sfx_btn.text = "🔊 Âm thanh (SFX): " + ("BẬT" if AudioSys.sound_enabled else "TẮT")
	_bgm_btn.text = "🎵 Nhạc nền (BGM): " + ("BẬT" if AudioSys.music_enabled else "TẮT")
	if AudioSys.is_speaker_unlocked():
		_track_btn.disabled = false
		var tname := "Lofi Chill" if AudioSys.current_bgm_index == 0 else "Upbeat Tiệm Vui"
		_track_btn.text = "📻 Kênh nhạc Loa: %s (Chạm để đổi)" % tname
	else:
		_track_btn.disabled = true
		_track_btn.text = "🔒 Mua 'Loa phát nhạc' trong Shop để mở thêm nhạc"

func _btn(txt: String, col: Color, min_sz: Vector2) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = min_sz
	b.add_theme_font_size_override("font_size", 24)
	var st := StyleBoxFlat.new()
	st.bg_color = col
	st.set_corner_radius_all(16)
	var sth := st.duplicate() as StyleBoxFlat
	sth.bg_color = col.lightened(0.14)
	var std := st.duplicate() as StyleBoxFlat
	std.bg_color = Color(0.24, 0.27, 0.34)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", sth)
	b.add_theme_stylebox_override("pressed", st)
	b.add_theme_stylebox_override("disabled", std)
	return b
