extends Node3D

signal customer_exited(customer: Node3D)

enum State { ENTERING, WAITING, HAPPY, DISAPPOINTED, EXITING }

const SHIRT_PALETTE: Array[Color] = [
	Color(0.95, 0.36, 0.38),
	Color(0.26, 0.65, 0.96),
	Color(0.40, 0.78, 0.42),
	Color(1.00, 0.70, 0.18),
	Color(0.67, 0.38, 0.90),
	Color(0.15, 0.78, 0.76),
	Color(0.96, 0.48, 0.68),
	Color(1.00, 0.52, 0.24),
	Color(0.36, 0.50, 0.92),
	Color(0.55, 0.82, 0.25)
]

var customer_name: String = "Anh Minh"
var customer_type: String = "normal" # normal | vip | kid | rush
var orders: Array[Dictionary] = [] # [{ "id": String, "needed": int, "got": int }]
var mood_ratio: float = 1.0

var _state: State = State.ENTERING
var _counter_ref: Node3D = null
var _slot_index: int = -1
var _exit_pos: Vector3 = Vector3(2.8, 0.0, 7.6)
var _target_pos: Vector3 = Vector3.ZERO
var _walk_speed: float = 3.6
var _base_patience_sec: float = 36.0
var _anim_phase: float = 0.0
var _combo_applied_any: bool = false

var _visual_root: Node3D
var _left_leg: Node3D
var _right_leg: Node3D
var _left_arm: Node3D
var _right_arm: Node3D
var _head_node: Node3D
var _order_bubble: Node3D

func setup(c_name: String, c_type: String, order_list: Array[Dictionary], counter: Node3D, slot_idx: int, entrance_pos: Vector3) -> void:
	customer_name = c_name
	customer_type = c_type
	orders = order_list
	_counter_ref = counter
	_slot_index = slot_idx
	_exit_pos = entrance_pos
	position = entrance_pos
	_target_pos = counter.call("get_slot_world_position", slot_idx)

	match customer_type:
		"vip":
			_base_patience_sec = 42.0
			_walk_speed = 3.5
		"kid":
			_base_patience_sec = 26.0
			_walk_speed = 4.1
		"rush":
			_base_patience_sec = 19.0
			_walk_speed = 4.9
		_:
			_base_patience_sec = 36.0
			_walk_speed = 3.6

	if is_inside_tree():
		if _visual_root != null:
			_visual_root.queue_free()
		_build_customer_visuals()
		if _order_bubble != null:
			_order_bubble.call("setup_customer_info", customer_name, customer_type)
			_order_bubble.call("update_orders", orders)
			_order_bubble.call("set_mood_ratio", 1.0)

func _ready() -> void:
	add_to_group("customers")
	_build_customer_visuals()
	_order_bubble = get_node_or_null("OrderBubble")
	if _order_bubble == null:
		var bubble_scene := load("res://scenes/entities/OrderBubble.tscn") as PackedScene
		if bubble_scene != null:
			_order_bubble = bubble_scene.instantiate()
			_order_bubble.position = Vector3(0, 2.05, 0)
			add_child(_order_bubble)

	if _order_bubble != null:
		_order_bubble.call("setup_customer_info", customer_name, customer_type)
		_order_bubble.call("update_orders", orders)
		_order_bubble.call("set_mood_ratio", 1.0)

func _build_customer_visuals() -> void:
	_visual_root = Node3D.new()
	_visual_root.name = "VisualRig"
	if customer_type == "kid":
		_visual_root.scale = Vector3(0.80, 0.80, 0.80)
	add_child(_visual_root)

	var shirt_col: Color = SHIRT_PALETTE[randi() % SHIRT_PALETTE.size()]
	var pants_col := Color(0.22, 0.25, 0.34)
	var skin_col := Color(1.0, 0.86, 0.74)
	var hair_colors: Array[Color] = [
		Color(0.16, 0.12, 0.10),
		Color(0.34, 0.22, 0.14),
		Color(0.45, 0.28, 0.18),
		Color(0.20, 0.18, 0.24)
	]
	var hair_col: Color = hair_colors[randi() % hair_colors.size()]

	# Shadow
	var sh := MeshInstance3D.new()
	var sh_cyl := CylinderMesh.new()
	sh_cyl.top_radius = 0.38
	sh_cyl.bottom_radius = 0.38
	sh_cyl.height = 0.02
	sh.mesh = sh_cyl
	var sh_mat := StandardMaterial3D.new()
	sh_mat.albedo_color = Color(0, 0, 0, 0.25)
	sh_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sh_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sh.material_override = sh_mat
	sh.position = Vector3(0, 0.02, 0)
	_visual_root.add_child(sh)

	# Legs
	for side in [-1, 1]:
		var lp := Node3D.new()
		lp.position = Vector3(side * 0.13, 0.32, 0)
		var lm := MeshInstance3D.new()
		var cap := CapsuleMesh.new()
		cap.radius = 0.085
		cap.height = 0.34
		lm.mesh = cap
		lm.position = Vector3(0, -0.15, 0)
		lm.material_override = _mat(pants_col)
		lp.add_child(lm)
		_visual_root.add_child(lp)
		if side < 0:
			_left_leg = lp
		else:
			_right_leg = lp

	# Torso
	var torso := MeshInstance3D.new()
	var tc := CylinderMesh.new()
	tc.top_radius = 0.23
	tc.bottom_radius = 0.26
	tc.height = 0.54
	torso.mesh = tc
	torso.position = Vector3(0, 0.60, 0)
	torso.material_override = _mat(shirt_col)
	_visual_root.add_child(torso)

	# Arms
	for side in [-1, 1]:
		var ap := Node3D.new()
		ap.position = Vector3(side * 0.28, 0.78, 0)
		var am := MeshInstance3D.new()
		var ac := CapsuleMesh.new()
		ac.radius = 0.07
		ac.height = 0.34
		am.mesh = ac
		am.position = Vector3(0, -0.14, 0)
		am.material_override = _mat(shirt_col)
		ap.add_child(am)
		_visual_root.add_child(ap)
		if side < 0:
			_left_arm = ap
		else:
			_right_arm = ap

	# Head pivot (for disappointed head-shake!)
	_head_node = Node3D.new()
	_head_node.position = Vector3(0, 1.15, 0)
	_visual_root.add_child(_head_node)

	var head_m := MeshInstance3D.new()
	var hs := SphereMesh.new()
	hs.radius = 0.27
	hs.height = 0.52
	head_m.mesh = hs
	head_m.material_override = _mat(skin_col)
	_head_node.add_child(head_m)

	var hair_m := MeshInstance3D.new()
	var hairs := SphereMesh.new()
	hairs.radius = 0.285
	hairs.height = 0.46
	hair_m.mesh = hairs
	hair_m.position = Vector3(0, 0.06, -0.03)
	hair_m.material_override = _mat(hair_col)
	_head_node.add_child(hair_m)

	for side in [-1, 1]:
		var eye := MeshInstance3D.new()
		var es := SphereMesh.new()
		es.radius = 0.038
		es.height = 0.076
		eye.mesh = es
		eye.position = Vector3(side * 0.09, 0.02, 0.24)
		eye.material_override = _mat(Color(0.1, 0.1, 0.12))
		_head_node.add_child(eye)

	# VIP Golden Crown!
	if customer_type == "vip":
		var crown := MeshInstance3D.new()
		var cc := CylinderMesh.new()
		cc.top_radius = 0.20
		cc.bottom_radius = 0.15
		cc.height = 0.18
		crown.mesh = cc
		crown.position = Vector3(0, 0.34, 0)
		var cmat := _mat(Color(1.0, 0.84, 0.10))
		cmat.emission_enabled = true
		cmat.emission = Color(0.65, 0.48, 0.0)
		crown.material_override = cmat
		_head_node.add_child(crown)

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.65
	return m

func _process(delta: float) -> void:
	match _state:
		State.ENTERING:
			_move_towards(_target_pos, delta, true)
		State.WAITING:
			_process_waiting(delta)
		State.EXITING:
			_move_towards(_exit_pos, delta, false)
		State.HAPPY, State.DISAPPOINTED:
			pass

func _move_towards(dest: Vector3, delta: float, arriving_counter: bool) -> void:
	var diff := dest - global_position
	diff.y = 0.0
	if diff.length() <= 0.14:
		global_position = Vector3(dest.x, 0.0, dest.z)
		if arriving_counter:
			_state = State.WAITING
			if _visual_root != null and _counter_ref != null:
				var look_dir := (_counter_ref.global_position - global_position)
				_visual_root.rotation.y = atan2(look_dir.x, look_dir.z)
			if _counter_ref != null and is_instance_valid(_counter_ref):
				_counter_ref.call("on_customer_arrived")
		else:
			customer_exited.emit(self)
			queue_free()
		return

	var dir := diff.normalized()
	global_position += dir * _walk_speed * delta
	if _visual_root != null:
		var ang := atan2(dir.x, dir.z)
		_visual_root.rotation.y = lerp_angle(_visual_root.rotation.y, ang, clampf(delta * 12.0, 0.0, 1.0))

	_anim_phase += delta * 12.0
	var sw := sin(_anim_phase) * 0.52
	if _left_leg != null:
		_left_leg.rotation.x = sw
	if _right_leg != null:
		_right_leg.rotation.x = -sw
	if _left_arm != null:
		_left_arm.rotation.x = -sw * 0.65
	if _right_arm != null:
		_right_arm.rotation.x = sw * 0.65
	if _visual_root != null:
		_visual_root.position.y = absf(sin(_anim_phase)) * 0.05

func _process_waiting(delta: float) -> void:
	_anim_phase += delta * 3.5
	if _left_leg != null:
		_left_leg.rotation.x = 0.0
	if _right_leg != null:
		_right_leg.rotation.x = 0.0
	if _visual_root != null:
		_visual_root.position.y = sin(_anim_phase) * 0.025

	var drain_mult := 1.0
	if not GameSys.is_lights_on():
		drain_mult *= 1.55
	drain_mult *= (1.0 - GameSys.get_decor_mood_bonus())

	mood_ratio -= (delta / _base_patience_sec) * drain_mult
	if _order_bubble != null:
		_order_bubble.call("set_mood_ratio", mood_ratio)

	if mood_ratio < 0.28 and _head_node != null:
		_head_node.rotation.y = sin(_anim_phase * 3.0) * 0.22

	if mood_ratio <= 0.0:
		_trigger_leave_disappointed()

func is_waiting_for_order() -> bool:
	return _state == State.WAITING or _state == State.ENTERING

func needs_item(food_id: String) -> bool:
	if not is_waiting_for_order():
		return false
	for entry in orders:
		if String(entry.get("id", "")) == food_id and int(entry.get("got", 0)) < int(entry.get("needed", 1)):
			return true
	return false

func deliver_item(food_id: String, is_combo: bool) -> void:
	if is_combo:
		_combo_applied_any = true
	for entry in orders:
		if String(entry.get("id", "")) == food_id and int(entry.get("got", 0)) < int(entry.get("needed", 1)):
			entry["got"] = int(entry.get("got", 0)) + 1
			mood_ratio = clampf(mood_ratio + 0.18, 0.0, 1.0)
			break
	if _order_bubble != null:
		_order_bubble.call("update_orders", orders)
		_order_bubble.call("set_mood_ratio", mood_ratio)

	var all_done := true
	for entry in orders:
		if int(entry.get("got", 0)) < int(entry.get("needed", 1)):
			all_done = false
			break
	if all_done:
		_complete_order_happy()

func _complete_order_happy() -> void:
	_state = State.HAPPY
	if _order_bubble != null:
		_order_bubble.call("set_bubble_visible", false)
	if _counter_ref != null and is_instance_valid(_counter_ref):
		_counter_ref.call("release_waiting_slot", self)

	# Calculate payout + tips + combo bonus!
	var base_sum := 0
	for entry in orders:
		var f := FoodDB.get_food(String(entry.get("id", "")))
		base_sum += int(f.get("price", 15)) * int(entry.get("needed", 1))

	var tip := 0
	var bonus_tags: Array[String] = []
	if customer_type == "vip":
		tip += int(round(randf_range(22.0, 42.0) * 2.0 * GameSys.get_rating_tip_multiplier()))
		bonus_tags.append("VIP Tip x2")
	elif customer_type == "rush" and mood_ratio >= 0.35:
		tip += int(round(randf_range(20.0, 38.0) * 3.0 * GameSys.get_rating_tip_multiplier()))
		bonus_tags.append("Phục vụ nhanh Tip x3!")
	elif mood_ratio >= 0.65:
		tip += int(round(randf_range(6.0, 16.0) * GameSys.get_rating_tip_multiplier()))

	tip += GameSys.get_decor_tip_bonus()

	var total := base_sum + tip
	if _combo_applied_any:
		total = int(round(float(total) * 1.5))
		bonus_tags.append("🔥 Combo x1.5!")

	GameSys.add_money(total)
	GameSys.on_customer_served_complete()
	AudioSys.play_sfx("coin_drop", 0.05)
	GameSys.sale_popup_requested.emit(total, global_position + Vector3(0, 1.8, 0), " • ".join(bonus_tags))

	# Happy jump celebration animation!
	var tw := create_tween()
	if _visual_root != null:
		tw.tween_property(_visual_root, "position:y", 0.52, 0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		tw.parallel().tween_property(_visual_root, "rotation:y", _visual_root.rotation.y + TAU, 0.34)
		tw.tween_property(_visual_root, "position:y", 0.0, 0.18).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tw.tween_callback(func() -> void:
		_state = State.EXITING
	)

func _trigger_leave_disappointed() -> void:
	_state = State.DISAPPOINTED
	if _order_bubble != null:
		_order_bubble.call("set_bubble_visible", false)
	if _counter_ref != null and is_instance_valid(_counter_ref):
		_counter_ref.call("release_waiting_slot", self)

	GameSys.on_customer_left_angry(customer_name)

	var tw := create_tween()
	if _head_node != null:
		tw.tween_property(_head_node, "rotation_degrees:y", -28.0, 0.10)
		tw.tween_property(_head_node, "rotation_degrees:y", 28.0, 0.10)
		tw.tween_property(_head_node, "rotation_degrees:y", -20.0, 0.10)
		tw.tween_property(_head_node, "rotation_degrees:y", 0.0, 0.10)
	tw.tween_callback(func() -> void:
		_state = State.EXITING
	)
