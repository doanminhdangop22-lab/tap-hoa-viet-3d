extends Control

signal start_game_requested()

var _loading_bar: ProgressBar
var _loading_lbl: Label
var _play_btn: Button
var _loading_active: bool = false
var _load_progress: float = 0.0

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build_splash_ui()

func _process(delta: float) -> void:
	if _loading_active:
		_load_progress = minf(100.0, _load_progress + delta * 135.0)
		_loading_bar.value = _load_progress
		_loading_lbl.text = "Đang dọn kệ & mở cửa tiệm... %d%%" % int(_load_progress)
		if _load_progress >= 100.0:
			_loading_active = false
			start_game_requested.emit()

func _build_splash_ui() -> void:
	var bg_color := ColorRect.new()
	bg_color.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg_color.color = Color(0.10, 0.14, 0.22)
	add_child(bg_color)

	if ResourceLoader.exists("res://assets/textures/ui/splash_bg.png"):
		var art := TextureRect.new()
		art.set_anchors_preset(Control.PRESET_FULL_RECT)
		art.texture = load("res://assets/textures/ui/splash_bg.png") as Texture2D
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		add_child(art)

	var grad := ColorRect.new()
	grad.set_anchors_preset(Control.PRESET_FULL_RECT)
	grad.color = Color(0.05, 0.08, 0.14, 0.48)
	add_child(grad)

	var bottom_card := PanelContainer.new()
	bottom_card.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom_card.offset_left = 56
	bottom_card.offset_right = -56
	bottom_card.offset_top = -690
	bottom_card.offset_bottom = -85
	var st := StyleBoxFlat.new()
	st.bg_color = Color(0.11, 0.15, 0.24, 0.93)
	st.border_color = Color(1.0, 0.82, 0.24)
	st.set_border_width_all(4)
	st.set_corner_radius_all(32)
	st.content_margin_left = 36
	st.content_margin_right = 36
	st.content_margin_top = 32
	st.content_margin_bottom = 32
	bottom_card.add_theme_stylebox_override("panel", st)
	add_child(bottom_card)

	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 16)
	bottom_card.add_child(v)

	var badge := Label.new()
	badge.text = "🏪 TẠP HOÁ VIỆT 3D"
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	badge.add_theme_font_size_override("font_size", 50)
	badge.add_theme_color_override("font_color", Color(1.0, 0.90, 0.30))
	badge.add_theme_color_override("font_outline_color", Color(0.18, 0.08, 0.04))
	badge.add_theme_constant_override("outline_size", 10)
	v.add_child(badge)

	var sub := Label.new()
	sub.text = "%s  •  💰 %dđ  •  ⭐ %.1f Sao" % [
		GameSys.get_store_name(),
		GameSys.get_money(),
		GameSys.get_rating_stars()
	]
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 24)
	sub.add_theme_color_override("font_color", Color(0.86, 0.95, 1.0))
	v.add_child(sub)

	var desc := Label.new()
	desc.text = "Bán 48 món ăn vặt tuổi thơ • Trang trí tiệm • Sưu tầm Skin 3D!\nHỗ trợ Cảm ứng (Android & iPhone) + Chuột & Phím (WASD, E, Space, B, V)"
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.add_theme_font_size_override("font_size", 19)
	desc.add_theme_color_override("font_color", Color(0.78, 0.86, 0.96))
	v.add_child(desc)

	_play_btn = Button.new()
	_play_btn.text = "▶ NHẤN ĐỂ VÀO CỬA HÀNG"
	_play_btn.custom_minimum_size = Vector2(0, 88)
	_play_btn.add_theme_font_size_override("font_size", 32)
	var bst := StyleBoxFlat.new()
	bst.bg_color = Color(0.20, 0.74, 0.38)
	bst.border_color = Color(0.65, 1.0, 0.72)
	bst.set_border_width_all(3)
	bst.set_corner_radius_all(22)
	var bsth := bst.duplicate() as StyleBoxFlat
	bsth.bg_color = Color(0.26, 0.82, 0.44)
	_play_btn.add_theme_stylebox_override("normal", bst)
	_play_btn.add_theme_stylebox_override("hover", bsth)
	_play_btn.add_theme_stylebox_override("pressed", bst)
	_play_btn.pressed.connect(_begin_loading)
	v.add_child(_play_btn)

	_loading_bar = ProgressBar.new()
	_loading_bar.custom_minimum_size = Vector2(0, 28)
	_loading_bar.max_value = 100.0
	_loading_bar.value = 0.0
	_loading_bar.show_percentage = false
	_loading_bar.visible = false
	var fg := StyleBoxFlat.new()
	fg.bg_color = Color(1.0, 0.80, 0.20)
	fg.set_corner_radius_all(12)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.18, 0.22, 0.32)
	bg.set_corner_radius_all(12)
	_loading_bar.add_theme_stylebox_override("fill", fg)
	_loading_bar.add_theme_stylebox_override("background", bg)
	v.add_child(_loading_bar)

	_loading_lbl = Label.new()
	_loading_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_loading_lbl.add_theme_font_size_override("font_size", 20)
	_loading_lbl.add_theme_color_override("font_color", Color(1.0, 0.92, 0.55))
	_loading_lbl.visible = false
	v.add_child(_loading_lbl)

func _unhandled_input(event: InputEvent) -> void:
	if _loading_active:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		var ke := event as InputEventKey
		if ke.keycode == KEY_ENTER or ke.keycode == KEY_SPACE:
			_begin_loading()

func _begin_loading() -> void:
	if _loading_active:
		return
	AudioSys.play_sfx("sell_ting")
	_play_btn.visible = false
	_loading_bar.visible = true
	_loading_lbl.visible = true
	_load_progress = 8.0
	_loading_active = true
