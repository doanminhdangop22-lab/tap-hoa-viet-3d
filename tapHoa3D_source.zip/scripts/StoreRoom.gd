extends Node3D

var _boxes_root: Node3D
var _box_mesh: Mesh
var _box_mat: StandardMaterial3D
var _tape_mat: StandardMaterial3D
var _spawn_index: int = 0

const STACK_SLOTS: Array[Vector3] = [
	Vector3(-1.1, 0.0, -0.3),
	Vector3(-0.4, 0.0, -0.3),
	Vector3(0.3, 0.0, -0.3),
	Vector3(1.0, 0.0, -0.3),
	Vector3(-0.75, 0.46, -0.3),
	Vector3(-0.05, 0.46, -0.3),
	Vector3(0.65, 0.46, -0.3),
	Vector3(-0.4, 0.92, -0.3)
]

func _ready() -> void:
	_build_storeroom_visuals()
	GameSys.restock_box_triggered.connect(_on_restock_box)

func _build_storeroom_visuals() -> void:
	# Backroom floor slab
	var floor_mesh := MeshInstance3D.new()
	var fb := BoxMesh.new()
	fb.size = Vector3(4.2, 0.14, 2.4)
	floor_mesh.mesh = fb
	floor_mesh.position = Vector3(0, -0.05, 0)
	var fmat := StandardMaterial3D.new()
	fmat.albedo_color = Color(0.58, 0.56, 0.54)
	floor_mesh.material_override = fmat
	add_child(floor_mesh)

	# Metal rack frame
	for side in [-1.6, 1.6]:
		var post := MeshInstance3D.new()
		var pb := BoxMesh.new()
		pb.size = Vector3(0.12, 2.1, 0.85)
		post.mesh = pb
		post.position = Vector3(float(side), 1.05, -0.35)
		var pmat := StandardMaterial3D.new()
		pmat.albedo_color = Color(0.32, 0.38, 0.44)
		post.material_override = pmat
		add_child(post)

	var font := load("res://assets/fonts/BeVietnamPro-ExtraBold.ttf") as Font
	var lbl := Label3D.new()
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.font = font
	lbl.font_size = 30
	lbl.outline_size = 8
	lbl.text = "📦 KHO NHẬP HÀNG"
	lbl.modulate = Color(1.0, 0.86, 0.45)
	lbl.pixel_size = 0.0044
	lbl.position = Vector3(0, 2.35, 0)
	add_child(lbl)

	if ResourceLoader.exists("res://assets/models/cardboard_box.obj"):
		_box_mesh = load("res://assets/models/cardboard_box.obj") as Mesh
	else:
		var b := BoxMesh.new()
		b.size = Vector3(0.55, 0.45, 0.50)
		_box_mesh = b

	_box_mat = StandardMaterial3D.new()
	_box_mat.albedo_color = Color(0.80, 0.58, 0.34)
	_box_mat.roughness = 0.82

	_tape_mat = StandardMaterial3D.new()
	_tape_mat.albedo_color = Color(0.95, 0.82, 0.48)

	_boxes_root = Node3D.new()
	_boxes_root.name = "BoxesRoot"
	add_child(_boxes_root)

	# Starter ambient boxes
	for i in range(4):
		_spawn_static_box(STACK_SLOTS[i])

func _spawn_static_box(pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	var m := MeshInstance3D.new()
	m.mesh = _box_mesh
	m.material_override = _box_mat
	n.add_child(m)

	var tape := MeshInstance3D.new()
	var tb := BoxMesh.new()
	tb.size = Vector3(0.56, 0.04, 0.12)
	tape.mesh = tb
	tape.position = Vector3(0, 0.46, 0)
	tape.material_override = _tape_mat
	n.add_child(tape)
	_boxes_root.add_child(n)
	return n

func _on_restock_box(food_id: String) -> void:
	if _boxes_root.get_child_count() >= 10:
		var oldest := _boxes_root.get_child(0)
		oldest.queue_free()
	var target_pos := STACK_SLOTS[_spawn_index % STACK_SLOTS.size()]
	_spawn_index += 1
	var box_node := _spawn_static_box(target_pos + Vector3(0, 2.4, 0))
	box_node.scale = Vector3(0.3, 0.3, 0.3)

	var icon_sp := Sprite3D.new()
	icon_sp.texture = FoodDB.get_food_icon(food_id)
	icon_sp.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	icon_sp.pixel_size = 0.004
	icon_sp.position = Vector3(0, 0.72, 0)
	box_node.add_child(icon_sp)

	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(box_node, "position", target_pos, 0.42).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tw.tween_property(box_node, "scale", Vector3.ONE, 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.chain().tween_interval(1.6)
	tw.chain().tween_callback(func() -> void:
		if is_instance_valid(icon_sp):
			icon_sp.queue_free()
	)
