extends Node

const SAVE_PATH := "user://save.json"
const AUTOSAVE_INTERVAL := 30.0

const DEFAULT_SHELF_FOODS: Array[String] = [
	"bim_bim_que",
	"banh_trang_nuong",
	"keo_deo_gau",
	"pocky",
	"tra_dao",
	"tra_sua_hop",
	"mi_ly_hao_hao",
	"kem_que_vani"
]

var data: Dictionary = {}
var pending_daily_bonus: int = 0
var pending_streak_bonus: int = 0
var _autosave_timer: Timer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_game()
	_check_daily_and_streak_bonus()
	_autosave_timer = Timer.new()
	_autosave_timer.wait_time = AUTOSAVE_INTERVAL
	_autosave_timer.autostart = true
	_autosave_timer.one_shot = false
	_autosave_timer.timeout.connect(save_game)
	add_child(_autosave_timer)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		save_game()

func get_default_data() -> Dictionary:
	var inv: Dictionary = {}
	for fid in DEFAULT_SHELF_FOODS:
		inv[fid] = 12
	return {
		"money": 500,
		"satisfaction": 80.0,
		"store_name": "TẠP HOÁ VUI VẺ",
		"lights_on": true,
		"sound_enabled": true,
		"music_enabled": true,
		"bgm_track": 0,
		"equipped_skin": "default",
		"owned_skins": ["default"],
		"placed_decor": [],
		"next_decor_uid": 1,
		"shelf_foods": DEFAULT_SHELF_FOODS.duplicate(),
		"inventory": inv,
		"last_login_date": "",
		"login_streak": 0,
		"wave_level": 1,
		"total_served": 0,
		"total_earned": 0
	}

func load_game() -> void:
	var defaults := get_default_data()
	if not FileAccess.file_exists(SAVE_PATH):
		data = defaults
		save_game()
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		data = defaults
		return
	var raw := f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(raw)
	if parsed is Dictionary:
		data = defaults
		for k in parsed.keys():
			data[k] = parsed[k]
		if not (data.get("shelf_foods") is Array) or (data["shelf_foods"] as Array).size() < 8:
			data["shelf_foods"] = DEFAULT_SHELF_FOODS.duplicate()
		if not (data.get("inventory") is Dictionary):
			data["inventory"] = defaults["inventory"]
		if not (data.get("owned_skins") is Array):
			data["owned_skins"] = ["default"]
		if not (data.get("placed_decor") is Array):
			data["placed_decor"] = []
	else:
		data = defaults

func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data, "\t"))
	f.close()

func _date_to_days(date_str: String) -> int:
	var parts := date_str.split("-")
	if parts.size() != 3:
		return -1
	var d := {
		"year": int(parts[0]),
		"month": int(parts[1]),
		"day": int(parts[2]),
		"hour": 12,
		"minute": 0,
		"second": 0
	}
	return int(Time.get_unix_time_from_datetime_dict(d) / 86400)

func _check_daily_and_streak_bonus() -> void:
	var today := Time.get_date_string_from_system()
	var last_date := String(data.get("last_login_date", ""))
	if last_date == today:
		return
	pending_daily_bonus = 200
	var streak := int(data.get("login_streak", 0))
	var today_days := _date_to_days(today)
	var last_days := _date_to_days(last_date)
	if last_days > 0 and (today_days - last_days) == 1:
		streak += 1
	else:
		streak = 1
	data["login_streak"] = streak
	data["last_login_date"] = today
	if streak > 0 and (streak % 7) == 0:
		pending_streak_bonus = 1000
	data["money"] = int(data.get("money", 500)) + pending_daily_bonus + pending_streak_bonus
	save_game()

func consume_pending_bonuses() -> Dictionary:
	var res := {
		"daily": pending_daily_bonus,
		"streak": pending_streak_bonus,
		"streak_days": int(data.get("login_streak", 1))
	}
	pending_daily_bonus = 0
	pending_streak_bonus = 0
	return res
