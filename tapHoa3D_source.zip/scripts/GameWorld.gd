extends Node3D

signal exit_to_splash()

var _camera: Camera3D
var _env: Environment
var _sun_light: DirectionalLight3D
var _ceiling_lights: Array[OmniLight3D] = []
var _lamp_bulbs: Array[StandardMaterial3D] = []
var _led_label: Label3D
var _led_backing_mat: StandardMaterial3D

var _player: CharacterBody3D
var _counter: StaticBody3D
var _decor_root: Node3D

var _hud: CanvasLayer
var _shop: CanvasLayer
var _decor_mode: CanvasLayer
var _pause_menu: CanvasLayer
var _result_popup: CanvasLayer

const SHELF_COORDS: Array[Vector3] = [
	Vector3(-3.75, 0.0, -3.55),
	Vector3(-3.75, 0.0, -1.05),
	Vector3(-3.75, 0.0, 1.45),
	Vector3(-3.75, 0.0, 3.95),
	Vector3(-1.05, 0.0, -3.55),
	Vector3(-1.05, 0.0, -1.05),
	Vector3(1.65, 0.0, -3.55),
	Vector3(4.15, 0.0, -1.05)
]

func _ready() -> void:
	_setup_camera_and_lighting()
	_build_store_architecture()
	_spawn_world_entities()
	_setup_ui_layers()
	_apply_lights_visuals(GameSys.is_lights_on())
	_update_led_sign(GameSys.get_store_name())

	GameSys.lights_toggled.connect(_apply_lights_visuals)
	GameSys.store_name_changed.connect(_update_led_sign)

	var bonuses := SaveSys.consume_pending_bonuses()
	if int(bonuses.get("daily", 0)) > 0:
		call_deferred("_show_initial_bonus", bonuses)

func _show_initial_bonus(bonuses: Dictionary) -> void:
	if _result_popup != null:
		_result_popup.call(
			"show_daily_reward",
			int(bonuses.get("daily", 200)),
			int(bonuses.get("streak", 0)),
			int(bonuses.get("streak_days", 1))
		)

func _setup_camera_and_lighting() -> void:
	_camera = Camera3D.new()
	_camera.keep_aspect = Camera3D.KEEP_WIDTH
	_camera.fov = 38.5
	add_child(_camera)
	_camera.look_at_from_position(Vector3(0.0, 16.4, 13.2), Vector3(0.0, 0.25, 0.45), Vector3.UP)

	var world_env := WorldEnvironment.new()
	_env = Environment.new()
	_env.background_mode = Environment.BG_COLOR
	_env.background_color = Color(0.55, 0.80, 0.98)
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_env.ambient_light_color = Color(0.95, 0.93, 0.88)
	_env.ambient_light_energy = 0.72
	world_env.environment = _env
	add_child(world_env)

	_sun_light = DirectionalLight3D.new()
	_sun_light.rotation_degrees = Vector3(-52.0, -28.0, 0.0)
	_sun_light.light_color = Color(1.0, 0.97, 0.90)
	_sun_light.light_energy = 1.05
	_sun_light.shadow_enabled = true
	add_child(_sun_light)

	# 4 Interior Ceiling Lamps
	var lamp_positions := [
		Vector3(-2.6, 3.2, -2.2),
		Vector3(2.2, 3.2, -2.2),
		Vector3(-2.4, 3.2, 2.5),
		Vector3(2.2, 3.2, 2.5)
	]
	for lp in lamp_positions:
		var omni := OmniLight3D.new()
		omni.position = lp
		omni.light_color = Color(1.0, 0.93, 0.78)
		omni.light_energy = 1.15
		omni.omni_range = 7.5
		add_child(omni)
		_ceiling_lights.append(omni)

		var fixture := MeshInstance3D.new()
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.22
		cyl.bottom_radius = 0.28
		cyl.height = 0.08
		fixture.mesh = cyl
		fixture.position = lp + Vector3(0, 0.15, 0)
		var bmat := StandardMaterial3D.new()
		bmat.albedo_color = Color(1.0, 0.96, 0.80)
		bmat.emission_enabled = true
		bmat.emission = Color(1.0, 0.92, 0.68)
		fixture.material_override = bmat
		add_child(fixture)
		_lamp_bulbs.append(bmat)

func _build_store_architecture() -> void:
	var arch := Node3D.new()
	arch.name = "Architecture"
	add_child(arch)

	# Store Interior Tiled Floor
	var floor_body := StaticBody3D.new()
	var floor_col := CollisionShape3D.new()
	var fshape := BoxShape3D.new()
	fshape.size = Vector3(11.0, 0.2, 12.6)
	floor_col.shape = fshape
	floor_col.position = Vector3(0, -0.1, 0.1)
	floor_body.add_child(floor_col)

	var floor_mesh := MeshInstance3D.new()
	var fbox := BoxMesh.new()
	fbox.size = Vector3(11.0, 0.2, 12.6)
	floor_mesh.mesh = fbox
	floor_mesh.position = Vector3(0, -0.1, 0.1)
	var fmat := StandardMaterial3D.new()
	if ResourceLoader.exists("res://assets/textures/world/floor_tile.png"):
		fmat.albedo_texture = load("res://assets/textures/world/floor_tile.png") as Texture2D
		fmat.uv1_scale = Vector3(8.0, 9.0, 1.0)
	else:
		fmat.albedo_color = Color(0.97, 0.94, 0.88)
	fmat.roughness = 0.45
	floor_mesh.material_override = fmat
	floor_body.add_child(floor_mesh)
	arch.add_child(floor_body)

	# Sunny Outdoor Sidewalk & Street (Front z = 6.4 .. 10.2)
	var sidewalk := MeshInstance3D.new()
	var sw_box := BoxMesh.new()
	sw_box.size = Vector3(14.5, 0.16, 2.2)
	sidewalk.mesh = sw_box
	sidewalk.position = Vector3(0, -0.12, 7.4)
	sidewalk.material_override = _solid_mat(Color(0.82, 0.80, 0.76))
	arch.add_child(sidewalk)

	var road := MeshInstance3D.new()
	var rd_box := BoxMesh.new()
	rd_box.size = Vector3(15.5, 0.14, 2.6)
	road.mesh = rd_box
	road.position = Vector3(0, -0.16, 9.7)
	road.material_override = _solid_mat(Color(0.28, 0.30, 0.34))
	arch.add_child(road)

	# Cute Vietnamese Sidewalk Red Plastic Stools (Ghế nhựa đỏ trà đá!) & Street Trees
	for sx in [-3.4, -2.5]:
		var stool := MeshInstance3D.new()
		var stb := BoxMesh.new()
		stb.size = Vector3(0.36, 0.36, 0.36)
		stool.mesh = stb
		stool.position = Vector3(float(sx), 0.18, 7.2)
		stool.material_override = _solid_mat(Color(0.90, 0.20, 0.20))
		arch.add_child(stool)

	for tx in [-5.8, 5.8]:
		var trunk := MeshInstance3D.new()
		var tc := CylinderMesh.new()
		tc.top_radius = 0.16
		tc.bottom_radius = 0.22
		tc.height = 1.4
		trunk.mesh = tc
		trunk.position = Vector3(float(tx), 0.7, 7.3)
		trunk.material_override = _solid_mat(Color(0.48, 0.32, 0.20))
		arch.add_child(trunk)
		var crown := MeshInstance3D.new()
		var cs := SphereMesh.new()
		cs.radius = 0.95
		cs.height = 1.7
		crown.mesh = cs
		crown.position = Vector3(float(tx), 1.95, 7.3)
		crown.material_override = _solid_mat(Color(0.28, 0.72, 0.34))
		arch.add_child(crown)

	# Back Wall (with open warehouse archway on right at x = 2.6)
	var back_left := MeshInstance3D.new()
	var bl_box := BoxMesh.new()
	bl_box.size = Vector3(6.6, 3.4, 0.28)
	back_left.mesh = bl_box
	back_left.position = Vector3(-2.2, 1.7, -6.15)
	back_left.material_override = _solid_mat(Color(0.98, 0.93, 0.82))
	arch.add_child(back_left)

	var back_header := MeshInstance3D.new()
	var bh_box := BoxMesh.new()
	bh_box.size = Vector3(4.4, 1.1, 0.28)
	back_header.mesh = bh_box
	back_header.position = Vector3(3.3, 2.85, -6.15)
	back_header.material_override = _solid_mat(Color(0.98, 0.93, 0.82))
	arch.add_child(back_header)

	# Left Wall
	var left_wall := MeshInstance3D.new()
	var lw_box := BoxMesh.new()
	lw_box.size = Vector3(0.28, 3.4, 12.6)
	left_wall.mesh = lw_box
	left_wall.position = Vector3(-5.5, 1.7, 0.1)
	left_wall.material_override = _solid_mat(Color(0.96, 0.90, 0.78))
	arch.add_child(left_wall)

	# Right & Front Cutaway Low Walls + Entrance Doorway at (2.8, 0, 6.2)
	var right_curb := MeshInstance3D.new()
	var rc_box := BoxMesh.new()
	rc_box.size = Vector3(0.26, 0.45, 12.6)
	right_curb.mesh = rc_box
	right_curb.position = Vector3(5.5, 0.22, 0.1)
	right_curb.material_override = _solid_mat(Color(0.20, 0.65, 0.58))
	arch.add_child(right_curb)

	var front_left_curb := MeshInstance3D.new()
	var flc := BoxMesh.new()
	flc.size = Vector3(6.8, 0.45, 0.26)
	front_left_curb.mesh = flc
	front_left_curb.position = Vector3(-2.1, 0.22, 6.3)
	front_left_curb.material_override = _solid_mat(Color(0.20, 0.65, 0.58))
	arch.add_child(front_left_curb)

	# Entrance Welcome Mat & Glass Door Pillars
	var mat_mesh := MeshInstance3D.new()
	var mb := BoxMesh.new()
	mb.size = Vector3(2.0, 0.03, 1.0)
	mat_mesh.mesh = mb
	mat_mesh.position = Vector3(2.8, 0.02, 6.1)
	mat_mesh.material_override = _solid_mat(Color(0.90, 0.28, 0.24))
	arch.add_child(mat_mesh)

	for dx in [1.65, 3.95]:
		var pillar := MeshInstance3D.new()
		var pb := BoxMesh.new()
		pb.size = Vector3(0.18, 2.35, 0.18)
		pillar.mesh = pb
		pillar.position = Vector3(float(dx), 1.18, 6.3)
		pillar.material_override = _solid_mat(Color(0.20, 0.65, 0.58))
		arch.add_child(pillar)

	# Red & White Striped Awning over Entrance + Storefront LED Board!
	for i in range(6):
		var stripe := MeshInstance3D.new()
		var sb := BoxMesh.new()
		sb.size = Vector3(0.44, 0.16, 0.85)
		stripe.mesh = sb
		stripe.position = Vector3(1.70 + i * 0.44, 2.42, 6.55)
		stripe.rotation_degrees = Vector3(18, 0, 0)
		var scol := Color(0.92, 0.22, 0.22) if (i % 2 == 0) else Color(0.99, 0.98, 0.95)
		stripe.material_override = _solid_mat(scol)
		arch.add_child(stripe)

	# Prominent Glowing LED Store Sign (mounted high on storefront/header so always crisp & visible!)
	var led_board := MeshInstance3D.new()
	var lb_box := BoxMesh.new()
	lb_box.size = Vector3(5.6, 0.92, 0.22)
	led_board.mesh = lb_box
	led_board.position = Vector3(-1.8, 3.55, -6.0)
	_led_backing_mat = StandardMaterial3D.new()
	_led_backing_mat.albedo_color = Color(0.10, 0.12, 0.18)
	_led_backing_mat.emission_enabled = true
	_led_backing_mat.emission = Color(0.08, 0.12, 0.24)
	led_board.material_override = _led_backing_mat
	arch.add_child(led_board)

	var font := load("res://assets/fonts/BeVietnamPro-ExtraBold.ttf") as Font
	_led_label = Label3D.new()
	_led_label.font = font
	_led_label.font_size = 54
	_led_label.outline_size = 12
	_led_label.modulate = Color(1.0, 0.90, 0.25)
	_led_label.outline_modulate = Color(0.85, 0.18, 0.25)
	_led_label.pixel_size = 0.0055
	_led_label.position = Vector3(-1.8, 3.55, -5.85)
	arch.add_child(_led_label)

	# Also a cute mini LED sign right above entrance door!
	var door_sign := Label3D.new()
	door_sign.font = font
	door_sign.font_size = 30
	door_sign.outline_size = 8
	door_sign.text = "OPEN 24/7 • MỜI VÀO"
	door_sign.modulate = Color(0.35, 1.0, 0.65)
	door_sign.pixel_size = 0.0045
	door_sign.position = Vector3(2.8, 2.72, 6.42)
	arch.add_child(door_sign)

func _solid_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.65
	return m

func _spawn_world_entities() -> void:
	# Backroom StoreRoom
	var sr_scene := load("res://scenes/world/StoreRoom.tscn") as PackedScene
	if sr_scene != null:
		var sr := sr_scene.instantiate() as Node3D
		sr.position = Vector3(3.1, 0.0, -7.55)
		add_child(sr)

	# 8 Shelves
	var shelf_scene := load("res://scenes/world/Shelf.tscn") as PackedScene
	if shelf_scene != null:
		for i in range(8):
			var sh := shelf_scene.instantiate() as StaticBody3D
			sh.set("shelf_index", i)
			sh.position = SHELF_COORDS[i]
			add_child(sh)

	# Checkout Counter
	var counter_scene := load("res://scenes/world/Counter.tscn") as PackedScene
	if counter_scene != null:
		_counter = counter_scene.instantiate() as StaticBody3D
		_counter.position = Vector3(-0.35, 0.0, 3.25)
		add_child(_counter)

	# Placed Decor 3D Container
	_decor_root = Node3D.new()
	_decor_root.name = "DecorRoot"
	add_child(_decor_root)

	# Player
	var player_scene := load("res://scenes/entities/Player.tscn") as PackedScene
	if player_scene != null:
		_player = player_scene.instantiate() as CharacterBody3D
		_player.position = Vector3(-0.35, 0.0, 1.85)
		add_child(_player)

	# Customer Spawner
	var spawner := Node3D.new()
	spawner.name = "CustomerSpawner"
	spawner.set_script(load("res://scripts/CustomerSpawner.gd"))
	add_child(spawner)

func _setup_ui_layers() -> void:
	var hud_scene := load("res://scenes/ui/HUD.tscn") as PackedScene
	_hud = hud_scene.instantiate() as CanvasLayer
	add_child(_hud)
	_hud.call("bind_player", _player)

	var shop_scene := load("res://scenes/ui/Shop.tscn") as PackedScene
	_shop = shop_scene.instantiate() as CanvasLayer
	add_child(_shop)

	var decor_scene := load("res://scenes/ui/DecorMode.tscn") as PackedScene
	_decor_mode = decor_scene.instantiate() as CanvasLayer
	add_child(_decor_mode)
	_decor_mode.call("bind_world_root", _decor_root)

	var pause_scene := load("res://scenes/ui/PauseMenu.tscn") as PackedScene
	_pause_menu = pause_scene.instantiate() as CanvasLayer
	add_child(_pause_menu)

	var popup_scene := load("res://scenes/ui/ResultPopup.tscn") as PackedScene
	_result_popup = popup_scene.instantiate() as CanvasLayer
	add_child(_result_popup)

	_hud.connect("shop_button_pressed", func() -> void:
		if not bool(_decor_mode.get("is_active")):
			_shop.call("open_shop", 0)
	)
	_hud.connect("decor_button_pressed", func() -> void:
		if not bool(_shop.get("is_open")):
			_decor_mode.call("open_decor_mode", -1)
	)
	_hud.connect("pause_button_pressed", func() -> void:
		_pause_menu.call("open_pause_menu")
	)
	_hud.connect("stats_button_pressed", func() -> void:
		_result_popup.call("show_store_summary")
	)
	_hud.connect("interact_button_pressed", func() -> void:
		if _player != null:
			_player.call("interact_nearest")
	)
	_hud.connect("joystick_updated", func(vec: Vector2) -> void:
		if _player != null:
			_player.call("set_joystick_input", vec)
	)
	_pause_menu.connect("return_to_splash_requested", func() -> void:
		exit_to_splash.emit()
	)

func _apply_lights_visuals(is_on: bool) -> void:
	for omni in _ceiling_lights:
		omni.visible = is_on
	for bmat in _lamp_bulbs:
		bmat.emission_enabled = is_on
		bmat.albedo_color = Color(1.0, 0.96, 0.80) if is_on else Color(0.35, 0.35, 0.40)
	if _env != null:
		_env.ambient_light_energy = 0.75 if is_on else 0.32
	if _sun_light != null:
		_sun_light.light_energy = 1.05 if is_on else 0.48

func _update_led_sign(new_name: String) -> void:
	if _led_label != null:
		_led_label.text = "✨ " + new_name.to_upper() + " ✨"

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var ke := event as InputEventKey
		if ke.keycode == KEY_F11:
			var mode := DisplayServer.window_get_mode()
			if mode == DisplayServer.WINDOW_MODE_FULLSCREEN:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			else:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
			get_viewport().set_input_as_handled()
			return

		var modal_busy := bool(_shop.get("is_open")) or bool(_decor_mode.get("is_active")) or bool(_pause_menu.get("is_open"))
		if not modal_busy:
			if ke.keycode == KEY_B:
				_shop.call("open_shop", 0)
				get_viewport().set_input_as_handled()
				return
			elif ke.keycode == KEY_V:
				_decor_mode.call("open_decor_mode", -1)
				get_viewport().set_input_as_handled()
				return
			elif ke.keycode == KEY_L:
				GameSys.set_lights_on(not GameSys.is_lights_on())
				get_viewport().set_input_as_handled()
				return
			elif ke.keycode == KEY_ESCAPE:
				_pause_menu.call("open_pause_menu")
				get_viewport().set_input_as_handled()
				return

	if bool(_shop.get("is_open")) or bool(_decor_mode.get("is_active")) or bool(_pause_menu.get("is_open")) or _result_popup.visible:
		return

	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT and mb.pressed:
			_handle_world_tap(mb.position)

func _handle_world_tap(screen_pos: Vector2) -> void:
	if _camera == null or _player == null:
		return
	var from := _camera.project_ray_origin(screen_pos)
	var to := from + _camera.project_ray_normal(screen_pos) * 50.0
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [_player.get_rid()]
	var hit := space.intersect_ray(query)

	if not hit.is_empty():
		var collider: Object = hit.get("collider")
		if collider is Node3D and (collider as Node3D).is_in_group("interactable"):
			var target_node := collider as Node3D
			var stand_pt := target_node.global_position
			if target_node.has_method("get_stand_point"):
				stand_pt = target_node.call("get_stand_point")
			_player.call("command_move_to", stand_pt, target_node)
			return

	var floor_pt: Variant = Plane(Vector3.UP, 0.0).intersects_ray(from, _camera.project_ray_normal(screen_pos))
	if floor_pt != null:
		_player.call("command_move_to", floor_pt as Vector3, null)
