extends Node3D

var _canvas_layer: CanvasLayer
var _panel: PanelContainer
var _panel_style: StyleBoxFlat
var _header_label: Label
var _items_box: HBoxContainer
var _mood_bar_fill: ColorRect
var _mood_bar_bg: ColorRect

var _mood_ratio: float = 1.0
var _pulse_time: float = 0.0
var _bubble_visible: bool = true

func _ready() -> void:
	_build_ui()

func _exit_tree() -> void:
	if _canvas_layer != null and is_instance_valid(_canvas_layer):
		_canvas_layer.queue_free()

func _build_ui() -> void:
	_canvas_layer = CanvasLayer.new()
	_canvas_layer.layer = 2
	add_child(_canvas_layer)

	_panel = PanelContainer.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel_style = StyleBoxFlat.new()
	_panel_style.bg_color = Color(0.11, 0.13, 0.18, 0.92)
	_panel_style.border_color = Color(1.0, 0.85, 0.35, 0.95)
	_panel_style.set_border_width_all(3)
	_panel_style.set_corner_radius_all(16)
	_panel_style.content_margin_left = 12
	_panel_style.content_margin_right = 12
	_panel_style.content_margin_top = 8
	_panel_style.content_margin_bottom = 8
	_panel.add_theme_stylebox_override("panel", _panel_style)
	_canvas_layer.add_child(_panel)

	var vbox := VBoxContainer.new()
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_theme_constant_override("separation", 5)
	_panel.add_child(vbox)

	_header_label = Label.new()
	_header_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_header_label.add_theme_font_size_override("font_size", 18)
	_header_label.add_theme_color_override("font_color", Color(1.0, 0.96, 0.82))
	vbox.add_child(_header_label)

	_items_box = HBoxContainer.new()
	_items_box.alignment = BoxContainer.ALIGNMENT_CENTER
	_items_box.add_theme_constant_override("separation", 8)
	_items_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(_items_box)

	_mood_bar_bg = ColorRect.new()
	_mood_bar_bg.custom_minimum_size = Vector2(148, 9)
	_mood_bar_bg.color = Color(0.22, 0.24, 0.28, 0.95)
	_mood_bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(_mood_bar_bg)

	_mood_bar_fill = ColorRect.new()
	_mood_bar_fill.color = Color(0.26, 0.82, 0.38)
	_mood_bar_fill.position = Vector2.ZERO
	_mood_bar_fill.size = Vector2(148, 9)
	_mood_bar_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mood_bar_bg.add_child(_mood_bar_fill)

func set_bubble_visible(v: bool) -> void:
	_bubble_visible = v
	if _panel != null:
		_panel.visible = v

func setup_customer_info(cust_name: String, cust_type: String) -> void:
	if _header_label == null:
		return
	match cust_type:
		"vip":
			_header_label.text = "👑 VIP • " + cust_name
			_header_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.22))
			_panel_style.border_color = Color(1.0, 0.80, 0.12)
		"rush":
			_header_label.text = "⚡ VỘI • " + cust_name
			_header_label.add_theme_color_override("font_color", Color(1.0, 0.56, 0.25))
			_panel_style.border_color = Color(1.0, 0.45, 0.18)
		"kid":
			_header_label.text = "🍬 " + cust_name
			_header_label.add_theme_color_override("font_color", Color(1.0, 0.72, 0.88))
			_panel_style.border_color = Color(0.96, 0.55, 0.78)
		_:
			_header_label.text = cust_name
			_header_label.add_theme_color_override("font_color", Color(0.95, 0.97, 1.0))
			_panel_style.border_color = Color(0.55, 0.78, 0.98)

func update_orders(orders: Array[Dictionary]) -> void:
	if _items_box == null:
		return
	for c in _items_box.get_children():
		c.queue_free()

	for entry in orders:
		var fid := String(entry.get("id", ""))
		var needed := int(entry.get("needed", 1))
		var got := int(entry.get("got", 0))
		var food := FoodDB.get_food(fid)

		var item_v := VBoxContainer.new()
		item_v.alignment = BoxContainer.ALIGNMENT_CENTER
		item_v.add_theme_constant_override("separation", 2)
		item_v.mouse_filter = Control.MOUSE_FILTER_IGNORE

		var row := HBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_CENTER
		row.add_theme_constant_override("separation", 3)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE

		var icon_rect := TextureRect.new()
		icon_rect.texture = FoodDB.get_food_icon(fid)
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_rect.custom_minimum_size = Vector2(38, 38)
		icon_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(icon_rect)

		var qty_lbl := Label.new()
		qty_lbl.add_theme_font_size_override("font_size", 18)
		if got >= needed:
			qty_lbl.text = "✓"
			qty_lbl.add_theme_color_override("font_color", Color(0.35, 1.0, 0.48))
		else:
			qty_lbl.text = "x%d" % (needed - got)
			qty_lbl.add_theme_color_override("font_color", Color.WHITE)
		row.add_child(qty_lbl)
		item_v.add_child(row)

		var name_lbl := Label.new()
		name_lbl.text = String(food.get("name", fid))
		name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name_lbl.add_theme_font_size_override("font_size", 14)
		name_lbl.add_theme_color_override("font_color", Color(0.84, 0.90, 0.96))
		item_v.add_child(name_lbl)

		_items_box.add_child(item_v)

func set_mood_ratio(ratio: float) -> void:
	_mood_ratio = clampf(ratio, 0.0, 1.0)
	if _mood_bar_fill == null or _mood_bar_bg == null:
		return
	var full_w := maxf(148.0, _mood_bar_bg.size.x)
	_mood_bar_fill.size = Vector2(full_w * _mood_ratio, 9.0)
	if _mood_ratio > 0.55:
		_mood_bar_fill.color = Color(0.24, 0.85, 0.38).lerp(Color(1.0, 0.82, 0.16), (1.0 - _mood_ratio) / 0.45)
	else:
		_mood_bar_fill.color = Color(1.0, 0.82, 0.16).lerp(Color(0.95, 0.22, 0.22), (0.55 - _mood_ratio) / 0.55)

func _process(delta: float) -> void:
	if _panel == null:
		return
	var cam := get_viewport().get_camera_3d()
	if cam == null or not _bubble_visible or not is_visible_in_tree():
		_panel.visible = false
		return
	if cam.is_position_behind(global_position):
		_panel.visible = false
		return
	_panel.visible = true
	var screen_pos := cam.unproject_position(global_position)
	var psize := _panel.size
	var y_bob := 0.0
	if _mood_ratio < 0.30:
		_pulse_time += delta * 12.0
		y_bob = sin(_pulse_time) * 4.0
	_panel.position = Vector2(screen_pos.x - psize.x * 0.5, screen_pos.y - psize.y - 8.0 + y_bob)
