extends Node3D

const MAX_STORE_CUSTOMERS := 6

const VIETNAMESE_NAMES: Array[String] = [
	"Anh Minh", "Chị Thảo", "Cô Lan", "Chú Hùng", "Bạn Tuấn",
	"Bạn Linh", "Anh Khôi", "Chị Mai", "Bác Tư", "Bạn Hà",
	"Anh Nam", "Chị Ngọc", "Cô Hạnh", "Chú Bình", "Bạn Vy",
	"Anh Đức", "Chị Trang", "Bạn Phúc", "Cô Thuỷ", "Anh Hoàng"
]

const KID_NAMES: Array[String] = [
	"Bé Bo", "Bé Na", "Bé Bắp", "Bé Sóc", "Bé Miu", "Bé Tí", "Bé Kem"
]

@export var entrance_position: Vector3 = Vector3(2.8, 0.0, 6.2)

var _customer_scene: PackedScene
var _counter_ref: Node3D
var _spawn_timer: float = 1.5
var _active_customers: Array[Node3D] = []

func _ready() -> void:
	_customer_scene = load("res://scenes/entities/Customer.tscn") as PackedScene
	call_deferred("_locate_counter")

func _locate_counter() -> void:
	var counters := get_tree().get_nodes_in_group("counter")
	if not counters.is_empty():
		_counter_ref = counters[0] as Node3D

func _process(delta: float) -> void:
	_cleanup_invalid_customers()
	var wave := GameSys.get_wave_level()
	var wave_cap := clampi(1 + wave, 2, MAX_STORE_CUSTOMERS)
	if _active_customers.size() >= wave_cap:
		return

	_spawn_timer -= delta * GameSys.get_spawn_rate_multiplier()
	if _spawn_timer <= 0.0:
		_try_spawn_customer()
		var base_cd := clampf(6.8 - float(wave) * 0.45, 3.0, 6.8)
		_spawn_timer = randf_range(base_cd * 0.78, base_cd * 1.15)

func _cleanup_invalid_customers() -> void:
	var valid: Array[Node3D] = []
	for c in _active_customers:
		if c != null and is_instance_valid(c):
			valid.append(c)
	_active_customers = valid

func _try_spawn_customer() -> void:
	if _counter_ref == null or not is_instance_valid(_counter_ref):
		_locate_counter()
	if _counter_ref == null or _customer_scene == null:
		return

	var cust := _customer_scene.instantiate() as Node3D
	var slot_idx := int(_counter_ref.call("claim_waiting_slot", cust))
	if slot_idx < 0:
		cust.queue_free()
		return

	var c_type := _roll_customer_type()
	var c_name := _pick_name(c_type)
	var orders := _generate_orders(c_type)

	add_child(cust)
	cust.call("setup", c_name, c_type, orders, _counter_ref, slot_idx, entrance_position)
	_active_customers.append(cust)
	cust.connect("customer_exited", _on_customer_exited)

	AudioSys.play_sfx("door_bell", 0.03)
	if c_type == "vip":
		GameSys.show_toast("👑 Khách VIP %s xuất hiện! (Tip x2)" % c_name, "vip")
	elif c_type == "rush":
		GameSys.show_toast("⚡ %s đang rất vội! Phục vụ kịp nhận Tip x3!" % c_name, "info")

func _roll_customer_type() -> String:
	var wave := GameSys.get_wave_level()
	var vip_bonus := 0.06 if GameSys.has_decor_placed("led_sign") else 0.0
	var r := randf()
	if wave == 1:
		if r < 0.16 + vip_bonus:
			return "vip"
		elif r < 0.34:
			return "kid"
		return "normal"
	if r < 0.18 + vip_bonus:
		return "vip"
	elif r < 0.36 + vip_bonus:
		return "rush"
	elif r < 0.54 + vip_bonus:
		return "kid"
	return "normal"

func _pick_name(c_type: String) -> String:
	if c_type == "kid":
		return KID_NAMES[randi() % KID_NAMES.size()]
	return VIETNAMESE_NAMES[randi() % VIETNAMESE_NAMES.size()]

func _generate_orders(c_type: String) -> Array[Dictionary]:
	var shelf_foods: Array = GameSys.get_shelf_foods()
	if shelf_foods.is_empty():
		shelf_foods = ["bim_bim_que"]

	var stocked_pool: Array[String] = []
	var all_pool: Array[String] = []
	var sweet_pool: Array[String] = []

	for f_var in shelf_foods:
		var fid := String(f_var)
		if not all_pool.has(fid):
			all_pool.append(fid)
		if GameSys.get_stock(fid) > 0 and not stocked_pool.has(fid):
			stocked_pool.append(fid)
		var fdata := FoodDB.get_food(fid)
		var cat := String(fdata.get("category", ""))
		if (cat == "sweet" or cat == "icecream") and not sweet_pool.has(fid):
			sweet_pool.append(fid)

	var candidate_pool := stocked_pool if not stocked_pool.is_empty() else all_pool
	if c_type == "kid" and not sweet_pool.is_empty():
		candidate_pool = sweet_pool

	var total_items := 1
	if c_type == "vip":
		total_items = randi_range(2, 3)
	elif c_type == "rush" and GameSys.get_wave_level() >= 3 and randf() < 0.35:
		total_items = 2

	var counts: Dictionary = {}
	for i in range(total_items):
		var chosen: String = candidate_pool[randi() % candidate_pool.size()]
		counts[chosen] = int(counts.get(chosen, 0)) + 1

	var result: Array[Dictionary] = []
	for k in counts.keys():
		result.append({
			"id": String(k),
			"needed": int(counts[k]),
			"got": 0
		})
	return result

func _on_customer_exited(c: Node3D) -> void:
	_active_customers.erase(c)
