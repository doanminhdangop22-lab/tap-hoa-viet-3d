extends Node

signal money_changed(new_money: int, delta: int)
signal rating_changed(stars: float, satisfaction: float)
signal store_name_changed(new_name: String)
signal lights_toggled(is_on: bool)
signal inventory_changed(food_id: String, new_amount: int)
signal shelf_assignment_changed(shelf_idx: int, food_id: String)
signal skin_changed(skin_id: String)
signal decor_updated()
signal combo_updated(streak: int, is_category_bonus: bool)
signal toast_requested(message: String, kind: String)
signal sale_popup_requested(amount: int, world_pos: Vector3, bonus_text: String)
signal restock_box_triggered(food_id: String)
signal wave_changed(wave: int)
signal enter_decor_place_mode(decor_id: String)

var _recent_sales: Array[Dictionary] = []
var streak_count: int = 0
var _last_sale_time: float = -100.0
var elapsed_play_time: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE

func _process(delta: float) -> void:
	elapsed_play_time += delta
	if streak_count > 0 and (elapsed_play_time - _last_sale_time) > 15.0:
		streak_count = 0
		combo_updated.emit(0, false)

func get_money() -> int:
	return int(SaveSys.data.get("money", 500))

func add_money(amount: int) -> void:
	if amount == 0:
		return
	var current := get_money()
	var updated := maxi(0, current + amount)
	SaveSys.data["money"] = updated
	if amount > 0:
		SaveSys.data["total_earned"] = int(SaveSys.data.get("total_earned", 0)) + amount
	money_changed.emit(updated, amount)

func spend_money(cost: int) -> bool:
	var current := get_money()
	if cost > current:
		return false
	SaveSys.data["money"] = current - cost
	money_changed.emit(current - cost, -cost)
	return true

func get_satisfaction() -> float:
	return clampf(float(SaveSys.data.get("satisfaction", 80.0)), 0.0, 100.0)

func get_rating_stars() -> float:
	return clampf(1.0 + (get_satisfaction() / 100.0) * 4.0, 1.0, 5.0)

func adjust_satisfaction(delta: float) -> void:
	var s := clampf(get_satisfaction() + delta, 0.0, 100.0)
	SaveSys.data["satisfaction"] = s
	rating_changed.emit(get_rating_stars(), s)

func get_spawn_rate_multiplier() -> float:
	var stars := get_rating_stars()
	var led_bonus := 0.12 if has_decor_placed("led_sign") else 0.0
	return clampf(0.75 + (stars - 1.0) * 0.20 + led_bonus, 0.65, 1.85)

func get_rating_tip_multiplier() -> float:
	var stars := get_rating_stars()
	return 0.8 + (stars - 1.0) * 0.18

func is_lights_on() -> bool:
	return bool(SaveSys.data.get("lights_on", true))

func set_lights_on(enabled: bool) -> void:
	SaveSys.data["lights_on"] = enabled
	lights_toggled.emit(enabled)
	if enabled:
		show_toast("Đã bật đèn cửa hàng — Khách vui vẻ hơn!", "info")
	else:
		show_toast("Đèn cửa hàng đang tắt — Mood khách giảm nhanh!", "warn")

func get_store_name() -> String:
	return String(SaveSys.data.get("store_name", "TẠP HOÁ VUI VẺ"))

func set_store_name(new_name: String) -> void:
	var cleaned := new_name.strip_edges()
	if cleaned == "":
		cleaned = "TẠP HOÁ VUI VẺ"
	SaveSys.data["store_name"] = cleaned
	SaveSys.save_game()
	store_name_changed.emit(cleaned)

func get_stock(food_id: String) -> int:
	var inv: Dictionary = SaveSys.data.get("inventory", {})
	return int(inv.get(food_id, 0))

func add_stock(food_id: String, delta: int) -> int:
	var inv: Dictionary = SaveSys.data.get("inventory", {})
	var cur := int(inv.get(food_id, 0))
	var next_val := maxi(0, cur + delta)
	inv[food_id] = next_val
	SaveSys.data["inventory"] = inv
	inventory_changed.emit(food_id, next_val)
	if next_val == 0 and cur > 0:
		var f := FoodDB.get_food(food_id)
		show_toast("Hết hàng %s! Vào Shop nhập thêm nhé!" % String(f.get("name", food_id)), "warn")
	return next_val

func get_total_store_stock() -> int:
	var total := 0
	for fid in get_shelf_foods():
		total += get_stock(String(fid))
	return total

func restock_food(food_id: String, units: int = 10) -> Dictionary:
	var food := FoodDB.get_food(food_id)
	if food.is_empty():
		return {"ok": false, "reason": "Món không tồn tại"}
	var cost := int(food.get("restock_cost", 50))
	var free_rescue := false
	if get_money() < cost and get_total_store_stock() == 0:
		cost = 0
		free_rescue = true
	if not spend_money(cost):
		return {"ok": false, "reason": "Không đủ tiền nhập hàng (%dđ)" % cost}
	var new_amt := add_stock(food_id, units)
	AudioSys.play_sfx("box_open")
	restock_box_triggered.emit(food_id)
	SaveSys.save_game()
	if free_rescue:
		show_toast("Hỗ trợ nhập khẩn cấp miễn phí +%d %s!" % [units, String(food.get("name", ""))], "vip")
	return {"ok": true, "stock": new_amt, "cost": cost}

func get_shelf_foods() -> Array:
	return SaveSys.data.get("shelf_foods", [])

func set_shelf_food(shelf_idx: int, food_id: String) -> void:
	var arr: Array = SaveSys.data.get("shelf_foods", [])
	if shelf_idx < 0 or shelf_idx >= arr.size():
		return
	arr[shelf_idx] = food_id
	SaveSys.data["shelf_foods"] = arr
	shelf_assignment_changed.emit(shelf_idx, food_id)
	SaveSys.save_game()

func record_item_sold(food_id: String) -> bool:
	var now := Time.get_ticks_msec() / 1000.0
	var food := FoodDB.get_food(food_id)
	var cat := String(food.get("category", "snack"))
	_recent_sales.append({"time": now, "id": food_id, "category": cat})
	var cutoff := now - 60.0
	var filtered: Array[Dictionary] = []
	var same_cat_count := 0
	var same_id_count := 0
	for s in _recent_sales:
		if float(s["time"]) >= cutoff:
			filtered.append(s)
			if String(s["category"]) == cat:
				same_cat_count += 1
			if String(s["id"]) == food_id:
				same_id_count += 1
	_recent_sales = filtered

	if (elapsed_play_time - _last_sale_time) <= 14.0:
		streak_count += 1
	else:
		streak_count = 1
	_last_sale_time = elapsed_play_time

	var is_combo := (same_id_count >= 5 or same_cat_count >= 5 or streak_count >= 5)
	if streak_count >= 2 or is_combo:
		combo_updated.emit(maxi(streak_count, maxi(same_id_count, same_cat_count)), is_combo)
	if is_combo and (streak_count == 5 or same_cat_count == 5):
		AudioSys.play_sfx("combo_fire", 0.02)
	return is_combo

func on_customer_served_complete() -> void:
	var served := int(SaveSys.data.get("total_served", 0)) + 1
	SaveSys.data["total_served"] = served
	adjust_satisfaction(2.4)
	var new_wave := 1 + int(served / 5)
	var old_wave := int(SaveSys.data.get("wave_level", 1))
	if new_wave > old_wave:
		SaveSys.data["wave_level"] = new_wave
		wave_changed.emit(new_wave)
		show_toast("Đợt khách cấp %d! Tiệm ngày càng đông vui!" % new_wave, "vip")

func on_customer_left_angry(customer_name: String) -> void:
	streak_count = 0
	combo_updated.emit(0, false)
	adjust_satisfaction(-8.0)
	AudioSys.play_sfx("customer_angry")
	show_toast("%s bỏ đi vì chờ lâu! (-Rating)" % customer_name, "error")

func get_wave_level() -> int:
	return maxi(1, int(SaveSys.data.get("wave_level", 1)))

func get_decor_mood_bonus() -> float:
	var bonus := 0.0
	var placed: Array = SaveSys.data.get("placed_decor", [])
	for p in placed:
		if p is Dictionary:
			var d := FoodDB.get_decor(String(p.get("id", "")))
			bonus += float(d.get("mood_bonus", 0.0))
	return clampf(bonus, 0.0, 0.45)

func get_decor_tip_bonus() -> int:
	var bonus := 0
	var placed: Array = SaveSys.data.get("placed_decor", [])
	for p in placed:
		if p is Dictionary:
			var d := FoodDB.get_decor(String(p.get("id", "")))
			bonus += int(d.get("tip_bonus", 0))
	return bonus

func has_decor_placed(decor_id: String) -> bool:
	var placed: Array = SaveSys.data.get("placed_decor", [])
	for p in placed:
		if p is Dictionary and String(p.get("id", "")) == decor_id:
			return true
	return false

func is_skin_owned(skin_id: String) -> bool:
	var owned: Array = SaveSys.data.get("owned_skins", ["default"])
	return owned.has(skin_id)

func get_equipped_skin() -> String:
	return String(SaveSys.data.get("equipped_skin", "default"))

func buy_or_equip_skin(skin_id: String) -> Dictionary:
	var skin := FoodDB.get_skin(skin_id)
	if skin.is_empty():
		return {"ok": false, "reason": "Skin không hợp lệ"}
	if is_skin_owned(skin_id):
		SaveSys.data["equipped_skin"] = skin_id
		SaveSys.save_game()
		skin_changed.emit(skin_id)
		return {"ok": true, "action": "equipped"}
	var price := int(skin.get("price", 0))
	if not spend_money(price):
		return {"ok": false, "reason": "Chưa đủ %dđ để mua trang phục này!" % price}
	var owned: Array = SaveSys.data.get("owned_skins", ["default"])
	owned.append(skin_id)
	SaveSys.data["owned_skins"] = owned
	SaveSys.data["equipped_skin"] = skin_id
	SaveSys.save_game()
	AudioSys.play_sfx("coin_drop")
	skin_changed.emit(skin_id)
	return {"ok": true, "action": "bought"}

func show_toast(msg: String, kind: String = "info") -> void:
	toast_requested.emit(msg, kind)
