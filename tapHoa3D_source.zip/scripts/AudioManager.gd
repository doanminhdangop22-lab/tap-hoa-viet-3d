extends Node

var _bgm_player: AudioStreamPlayer
var _sfx_pool: Array[AudioStreamPlayer] = []
var _bgm_streams: Array[AudioStream] = []
var _sfx_streams: Dictionary = {}

var sound_enabled: bool = true
var music_enabled: bool = true
var current_bgm_index: int = 0

const SFX_PATHS: Dictionary = {
	"door_bell": "res://assets/audio/sfx/door_bell.wav",
	"sell_ting": "res://assets/audio/sfx/sell_ting.wav",
	"coin_drop": "res://assets/audio/sfx/coin_drop.wav",
	"customer_angry": "res://assets/audio/sfx/customer_angry.wav",
	"box_open": "res://assets/audio/sfx/box_open.wav",
	"pickup_item": "res://assets/audio/sfx/pickup_item.wav",
	"ui_click": "res://assets/audio/sfx/ui_click.wav",
	"combo_fire": "res://assets/audio/sfx/combo_fire.wav"
}

const BGM_PATHS: Array[String] = [
	"res://assets/audio/bgm/lofi_chill.wav",
	"res://assets/audio/bgm/upbeat_funk.wav"
]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	sound_enabled = bool(SaveSys.data.get("sound_enabled", true))
	music_enabled = bool(SaveSys.data.get("music_enabled", true))
	current_bgm_index = int(SaveSys.data.get("bgm_track", 0))

	_bgm_player = AudioStreamPlayer.new()
	_bgm_player.volume_db = -7.0
	add_child(_bgm_player)
	_bgm_player.finished.connect(_on_bgm_finished)

	for i in range(10):
		var p := AudioStreamPlayer.new()
		p.volume_db = -3.0
		add_child(p)
		_sfx_pool.append(p)

	for path in BGM_PATHS:
		if ResourceLoader.exists(path):
			var stream := load(path) as AudioStream
			if stream is AudioStreamWAV:
				var wav := stream as AudioStreamWAV
				wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
				wav.loop_begin = 0
				var bytes_per_sample := 2 if wav.format == AudioStreamWAV.FORMAT_16_BITS else 1
				var channels := 2 if wav.stereo else 1
				wav.loop_end = int(wav.data.size() / maxi(1, bytes_per_sample * channels))
			if stream != null:
				_bgm_streams.append(stream)

	for key in SFX_PATHS.keys():
		var p_str := String(SFX_PATHS[key])
		if ResourceLoader.exists(p_str):
			var s := load(p_str) as AudioStream
			if s != null:
				_sfx_streams[key] = s

	play_bgm(current_bgm_index)

func _on_bgm_finished() -> void:
	if music_enabled and _bgm_player.stream != null:
		_bgm_player.play()

func play_bgm(index: int = 0) -> void:
	if _bgm_streams.is_empty():
		return
	current_bgm_index = clampi(index, 0, _bgm_streams.size() - 1)
	SaveSys.data["bgm_track"] = current_bgm_index
	_bgm_player.stream = _bgm_streams[current_bgm_index]
	if music_enabled:
		if not _bgm_player.playing:
			_bgm_player.play()
	else:
		_bgm_player.stop()

func toggle_bgm_track() -> int:
	if not is_speaker_unlocked():
		return 0
	var next_idx := (current_bgm_index + 1) % maxi(1, _bgm_streams.size())
	_bgm_player.stop()
	play_bgm(next_idx)
	return current_bgm_index

func is_speaker_unlocked() -> bool:
	var placed: Array = SaveSys.data.get("placed_decor", [])
	for entry in placed:
		if entry is Dictionary and String(entry.get("id", "")) == "music_speaker":
			return true
	return false

func set_sound_enabled(enabled: bool) -> void:
	sound_enabled = enabled
	SaveSys.data["sound_enabled"] = enabled
	SaveSys.save_game()

func set_music_enabled(enabled: bool) -> void:
	music_enabled = enabled
	SaveSys.data["music_enabled"] = enabled
	if music_enabled:
		play_bgm(current_bgm_index)
	else:
		_bgm_player.stop()
	SaveSys.save_game()

func play_sfx(sfx_name: String, pitch_variation: float = 0.05) -> void:
	if not sound_enabled:
		return
	if not _sfx_streams.has(sfx_name):
		return
	var stream: AudioStream = _sfx_streams[sfx_name]
	for p in _sfx_pool:
		if not p.playing:
			p.stream = stream
			p.pitch_scale = randf_range(1.0 - pitch_variation, 1.0 + pitch_variation)
			p.play()
			return
	var fallback := _sfx_pool[0]
	fallback.stream = stream
	fallback.pitch_scale = 1.0
	fallback.play()
