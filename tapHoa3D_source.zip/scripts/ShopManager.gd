extends CanvasLayer

signal shop_closed()

const PlayerScript := preload("res://scripts/Player.gd")

var is_open: bool = false
var _current_tab: int = 0
var _selected_category: String = "all"
var _selected_shelf_slot: int = 0
var _preview_skin_id: String = "default"

var _money_label: Label
var _tab_buttons: Array[Button] = []
var _tab_containers: Array[Control] = []

# Tab 1 nodes
var _shelf_slot_buttons: Array[Button] = []
var _cat_buttons: Dictionary = {}
var _food_grid: GridContainer

# Tab 2 nodes
var _preview_char_root: Node3D
var _preview_title_lbl: Label
var _preview_desc_lbl: Label
var _preview_buy_btn: Button
var _skin_grid: GridContainer

# Tab 3 nodes
var _decor_grid: GridContainer

func _ready() -> void:
	layer = 10
	visible = false
	_build_shop_ui()
	GameSys.money_changed.connect(_on_money_changed)
	GameSys.inventory_changed.connect(func(_id: String, _amt: int) -> void:
		if is_open and _current_tab == 0:
			_populate_food_grid()
	)

func _process(delta: float) -> void:
	if is_open and _current_tab == 1 and _preview_char_root != null:
		_preview_char_root.rotation.y += delta * 1.4

func open_shop(tab_idx: int = 0) -> void:
	is_open = true
	visible = true
	_preview_skin_id = GameSys.get_equipped_skin()
	_update_money_header()
	_switch_tab(tab_idx)
	_set_player_blocked(true)
	AudioSys.play_sfx("ui_click")

func close_shop() -> void:
	if not is_open:
		return
	is_open = false
	visible = false
	_set_player_blocked(false)
	AudioSys.play_sfx("ui_click")
	shop_closed.emit()

func _set_player_blocked(blocked: bool) -> void:
	for p in get_tree().get_nodes_in_group("player"):
		p.set("ui_blocking_input", blocked)

func _unhandled_input(event: InputEvent) -> void:
	if not is_open:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		var ke := event as InputEventKey
		if ke.keycode == KEY_ESCAPE or ke.keycode == KEY_B:
			close_shop()
			get_viewport().set_input_as_handled()

func _on_money_changed(_new_money: int, _delta: int) -> void:
	if is_open:
		_update_money_header()

func _update_money_header() -> void:
	if _money_label != null:
		_money_label.text = "💰 %dđ" % GameSys.get_money()

func _build_shop_ui() -> void:
	var backdrop := ColorRect.new()
	backdrop.set_anchors_preset(Control.PRESET_FULL_RECT)
	backdrop.color = Color(0.04, 0.06, 0.10, 0.76)
	add_child(backdrop)

	var main_card := PanelContainer.new()
	main_card.set_anchors_preset(Control.PRESET_FULL_RECT)
	main_card.offset_left = 34
	main_card.offset_right = -34
	main_card.offset_top = 70
	main_card.offset_bottom = -70
	var card_st := StyleBoxFlat.new()
	card_st.bg_color = Color(0.12, 0.15, 0.22, 0.98)
	card_st.border_color = Color(1.0, 0.76, 0.22)
	card_st.set_border_width_all(4)
	card_st.set_corner_radius_all(28)
	card_st.content_margin_left = 24
	card_st.content_margin_right = 24
	card_st.content_margin_top = 22
	card_st.content_margin_bottom = 22
	main_card.add_theme_stylebox_override("panel", card_st)
	add_child(main_card)

	var root_v := VBoxContainer.new()
	root_v.add_theme_constant_override("separation", 16)
	main_card.add_child(root_v)

	# Header bar
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 14)
	root_v.add_child(header)

	var title := Label.new()
	title.text = "🏪 CỬA HÀNG TẠP HOÁ"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 32)
	title.add_theme_color_override("font_color", Color(1.0, 0.92, 0.42))
	header.add_child(title)

	_money_label = Label.new()
	_money_label.add_theme_font_size_override("font_size", 30)
	_money_label.add_theme_color_override("font_color", Color(0.45, 1.0, 0.56))
	header.add_child(_money_label)

	var close_btn := _styled_btn("✕ Đóng", Color(0.84, 0.25, 0.28), Vector2(130, 62), 24)
	close_btn.pressed.connect(close_shop)
	header.add_child(close_btn)

	# 3 Tab Buttons
	var tab_row := HBoxContainer.new()
	tab_row.add_theme_constant_override("separation", 12)
	root_v.add_child(tab_row)
	var tab_names := ["📦 NHẬP HÀNG", "👕 SKIN NHÂN VẬT", "🎨 TRANG TRÍ"]
	for i in range(tab_names.size()):
		var tb := _styled_btn(tab_names[i], Color(0.22, 0.28, 0.40), Vector2(0, 68), 23)
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var idx := i
		tb.pressed.connect(func() -> void:
			AudioSys.play_sfx("ui_click")
			_switch_tab(idx)
		)
		tab_row.add_child(tb)
		_tab_buttons.append(tb)

	# Tab 1: Restock & Shelf Assignment
	var tab1 := _build_tab1_restock()
	tab1.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_v.add_child(tab1)
	_tab_containers.append(tab1)

	# Tab 2: Character Skins + Live 3D Preview
	var tab2 := _build_tab2_skins()
	tab2.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_v.add_child(tab2)
	_tab_containers.append(tab2)

	# Tab 3: Store Decorations
	var tab3 := _build_tab3_decor()
	tab3.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_v.add_child(tab3)
	_tab_containers.append(tab3)

func _build_tab1_restock() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)

	# Shelf selector row so player can assign any of the 48 foods to any of the 8 shelves!
	var shelf_lbl := Label.new()
	shelf_lbl.text = "Chọn kệ muốn đổi món trưng bày (8 kệ trong tiệm):"
	shelf_lbl.add_theme_font_size_override("font_size", 20)
	shelf_lbl.add_theme_color_override("font_color", Color(0.80, 0.88, 0.98))
	v.add_child(shelf_lbl)

	var shelf_row := GridContainer.new()
	shelf_row.columns = 4
	shelf_row.add_theme_constant_override("h_separation", 8)
	shelf_row.add_theme_constant_override("v_separation", 8)
	v.add_child(shelf_row)

	for s_idx in range(8):
		var sb := _styled_btn("Kệ %d" % (s_idx + 1), Color(0.20, 0.25, 0.35), Vector2(0, 52), 18)
		sb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var captured := s_idx
		sb.pressed.connect(func() -> void:
			_selected_shelf_slot = captured
			AudioSys.play_sfx("ui_click")
			_refresh_shelf_slot_buttons()
			_populate_food_grid()
		)
		shelf_row.add_child(sb)
		_shelf_slot_buttons.append(sb)

	# Category filter row
	var cat_row := HBoxContainer.new()
	cat_row.add_theme_constant_override("separation", 8)
	v.add_child(cat_row)
	var cats: Array[String] = ["all", "snack", "sweet", "drink", "noodle", "icecream"]
	for c in cats:
		var cb := _styled_btn(FoodDB.get_category_name(c), Color(0.22, 0.30, 0.42), Vector2(0, 54), 20)
		cb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cat_code: String = c
		cb.pressed.connect(func() -> void:
			_selected_category = cat_code
			AudioSys.play_sfx("ui_click")
			_refresh_category_buttons()
			_populate_food_grid()
		)
		cat_row.add_child(cb)
		_cat_buttons[c] = cb

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)

	_food_grid = GridContainer.new()
	_food_grid.columns = 2
	_food_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_food_grid.add_theme_constant_override("h_separation", 14)
	_food_grid.add_theme_constant_override("v_separation", 14)
	scroll.add_child(_food_grid)
	return v

func _build_tab2_skins() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)

	# Live 3D Preview Box!
	var preview_panel := PanelContainer.new()
	preview_panel.custom_minimum_size = Vector2(0, 410)
	var pst := StyleBoxFlat.new()
	pst.bg_color = Color(0.16, 0.21, 0.31)
	pst.border_color = Color(0.42, 0.72, 1.0)
	pst.set_border_width_all(2)
	pst.set_corner_radius_all(20)
	pst.content_margin_left = 18
	pst.content_margin_right = 18
	pst.content_margin_top = 14
	pst.content_margin_bottom = 14
	preview_panel.add_theme_stylebox_override("panel", pst)
	v.add_child(preview_panel)

	var preview_h := HBoxContainer.new()
	preview_h.add_theme_constant_override("separation", 20)
	preview_panel.add_child(preview_h)

	var sub_vc := SubViewportContainer.new()
	sub_vc.stretch = true
	sub_vc.custom_minimum_size = Vector2(340, 360)
	preview_h.add_child(sub_vc)

	var sub_vp := SubViewport.new()
	sub_vp.own_world_3d = true
	sub_vp.transparent_bg = true
	sub_vp.size = Vector2i(340, 360)
	sub_vc.add_child(sub_vp)

	var preview_root_3d := Node3D.new()
	sub_vp.add_child(preview_root_3d)

	var cam := Camera3D.new()
	cam.fov = 38.0
	preview_root_3d.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.25, 2.85), Vector3(0, 0.88, 0), Vector3.UP)

	var key_light := DirectionalLight3D.new()
	key_light.rotation_degrees = Vector3(-38, 32, 0)
	key_light.light_energy = 1.35
	preview_root_3d.add_child(key_light)

	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.88, 0.90, 0.96)
	env.ambient_light_energy = 0.85
	env_node.environment = env
	preview_root_3d.add_child(env_node)

	_preview_char_root = Node3D.new()
	preview_root_3d.add_child(_preview_char_root)

	var info_v := VBoxContainer.new()
	info_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_v.alignment = BoxContainer.ALIGNMENT_CENTER
	info_v.add_theme_constant_override("separation", 14)
	preview_h.add_child(info_v)

	_preview_title_lbl = Label.new()
	_preview_title_lbl.add_theme_font_size_override("font_size", 28)
	_preview_title_lbl.add_theme_color_override("font_color", Color(1.0, 0.90, 0.38))
	_preview_title_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_v.add_child(_preview_title_lbl)

	_preview_desc_lbl = Label.new()
	_preview_desc_lbl.add_theme_font_size_override("font_size", 21)
	_preview_desc_lbl.add_theme_color_override("font_color", Color(0.86, 0.92, 0.98))
	_preview_desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_v.add_child(_preview_desc_lbl)

	_preview_buy_btn = _styled_btn("Mặc ngay", Color(0.20, 0.72, 0.38), Vector2(0, 74), 25)
	_preview_buy_btn.pressed.connect(_on_preview_skin_action)
	info_v.add_child(_preview_buy_btn)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)

	_skin_grid = GridContainer.new()
	_skin_grid.columns = 2
	_skin_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_skin_grid.add_theme_constant_override("h_separation", 14)
	_skin_grid.add_theme_constant_override("v_separation", 14)
	scroll.add_child(_skin_grid)
	return v

func _build_tab3_decor() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)

	var hint := Label.new()
	hint.text = "Mua nội thất để đặt vào cửa hàng (kéo thả xoay tuỳ ý, xoá hoàn tiền 50%):"
	hint.add_theme_font_size_override("font_size", 21)
	hint.add_theme_color_override("font_color", Color(0.84, 0.92, 1.0))
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(hint)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)

	_decor_grid = GridContainer.new()
	_decor_grid.columns = 2
	_decor_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_decor_grid.add_theme_constant_override("h_separation", 14)
	_decor_grid.add_theme_constant_override("v_separation", 14)
	scroll.add_child(_decor_grid)
	return v

func _switch_tab(idx: int) -> void:
	_current_tab = clampi(idx, 0, 2)
	for i in range(_tab_containers.size()):
		_tab_containers[i].visible = (i == _current_tab)
		var btn_col := Color(0.95, 0.56, 0.14) if (i == _current_tab) else Color(0.22, 0.28, 0.40)
		_apply_btn_color(_tab_buttons[i], btn_col)

	if _current_tab == 0:
		_refresh_shelf_slot_buttons()
		_refresh_category_buttons()
		_populate_food_grid()
	elif _current_tab == 1:
		_refresh_skin_preview(_preview_skin_id)
		_populate_skin_grid()
	elif _current_tab == 2:
		_populate_decor_grid()

func _refresh_shelf_slot_buttons() -> void:
	var shelves := GameSys.get_shelf_foods()
	for i in range(_shelf_slot_buttons.size()):
		var fid := String(shelves[i]) if i < shelves.size() else ""
		var f := FoodDB.get_food(fid)
		var short_name := String(f.get("name", "")).substr(0, 10)
		_shelf_slot_buttons[i].text = "Kệ %d: %s" % [i + 1, short_name]
		var col := Color(0.18, 0.65, 0.55) if i == _selected_shelf_slot else Color(0.20, 0.25, 0.35)
		_apply_btn_color(_shelf_slot_buttons[i], col)

func _refresh_category_buttons() -> void:
	for k in _cat_buttons.keys():
		var btn: Button = _cat_buttons[k]
		var col := Color(0.22, 0.62, 0.88) if String(k) == _selected_category else Color(0.22, 0.30, 0.42)
		_apply_btn_color(btn, col)

func _populate_food_grid() -> void:
	for c in _food_grid.get_children():
		c.queue_free()

	var foods := FoodDB.get_foods_by_category(_selected_category)
	var shelves := GameSys.get_shelf_foods()

	for item in foods:
		var fid := String(item.get("id", ""))
		var fname := String(item.get("name", fid))
		var sell_price := int(item.get("price", 15))
		var restock_cost := int(item.get("restock_cost", 55))
		var stock := GameSys.get_stock(fid)
		var shelf_idx := shelves.find(fid)

		var card := _card_panel()
		_food_grid.add_child(card)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 8)
		card.add_child(cv)

		var top_h := HBoxContainer.new()
		top_h.add_theme_constant_override("separation", 10)
		cv.add_child(top_h)

		var icon := TextureRect.new()
		icon.texture = FoodDB.get_food_icon(fid)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.custom_minimum_size = Vector2(72, 72)
		top_h.add_child(icon)

		var meta_v := VBoxContainer.new()
		meta_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		top_h.add_child(meta_v)

		var nl := Label.new()
		nl.text = fname
		nl.add_theme_font_size_override("font_size", 21)
		nl.add_theme_color_override("font_color", Color.WHITE)
		nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		meta_v.add_child(nl)

		var pl := Label.new()
		pl.text = "Giá bán: %dđ/món  •  Kho: %d" % [sell_price, stock]
		pl.add_theme_font_size_override("font_size", 17)
		pl.add_theme_color_override("font_color", Color(0.55, 0.96, 0.65) if stock > 0 else Color(1.0, 0.48, 0.48))
		meta_v.add_child(pl)

		if shelf_idx >= 0:
			var sl := Label.new()
			sl.text = "✓ Đang trưng ở Kệ %d" % (shelf_idx + 1)
			sl.add_theme_font_size_override("font_size", 16)
			sl.add_theme_color_override("font_color", Color(1.0, 0.85, 0.32))
			meta_v.add_child(sl)

		var btn_h := HBoxContainer.new()
		btn_h.add_theme_constant_override("separation", 8)
		cv.add_child(btn_h)

		var restock_btn := _styled_btn("+10 Kho (%dđ)" % restock_cost, Color(0.20, 0.68, 0.36), Vector2(0, 52), 18)
		restock_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		restock_btn.pressed.connect(func() -> void:
			var res := GameSys.restock_food(fid, 10)
			if not bool(res.get("ok", false)):
				GameSys.show_toast(String(res.get("reason", "")), "warn")
			else:
				_populate_food_grid()
				_refresh_shelf_slot_buttons()
		)
		btn_h.add_child(restock_btn)

		var assign_btn := _styled_btn("Đặt Kệ %d" % (_selected_shelf_slot + 1), Color(0.24, 0.52, 0.85), Vector2(130, 52), 18)
		assign_btn.disabled = (shelf_idx == _selected_shelf_slot)
		assign_btn.pressed.connect(func() -> void:
			GameSys.set_shelf_food(_selected_shelf_slot, fid)
			AudioSys.play_sfx("pickup_item")
			_refresh_shelf_slot_buttons()
			_populate_food_grid()
		)
		btn_h.add_child(assign_btn)

func _refresh_skin_preview(skin_id: String) -> void:
	_preview_skin_id = skin_id
	if _preview_char_root != null:
		PlayerScript.populate_character_meshes(_preview_char_root, skin_id, true)
	var s := FoodDB.get_skin(skin_id)
	_preview_title_lbl.text = String(s.get("name", skin_id))
	var bonus_spd := int(round(float(s.get("speed_bonus", 0.0)) * 16.0))
	var bonus_str := (" (+%d%% tốc độ chạy)" % bonus_spd) if bonus_spd > 0 else ""
	_preview_desc_lbl.text = String(s.get("description", "")) + bonus_str

	var equipped := (GameSys.get_equipped_skin() == skin_id)
	var owned := GameSys.is_skin_owned(skin_id)
	var price := int(s.get("price", 0))
	if equipped:
		_preview_buy_btn.text = "✓ Đang mặc"
		_preview_buy_btn.disabled = true
		_apply_btn_color(_preview_buy_btn, Color(0.32, 0.42, 0.48))
	elif owned:
		_preview_buy_btn.text = "Mặc trang phục này"
		_preview_buy_btn.disabled = false
		_apply_btn_color(_preview_buy_btn, Color(0.18, 0.62, 0.88))
	else:
		_preview_buy_btn.text = "Mua & Mặc (%dđ)" % price
		_preview_buy_btn.disabled = false
		_apply_btn_color(_preview_buy_btn, Color(0.22, 0.72, 0.36))

func _on_preview_skin_action() -> void:
	var res := GameSys.buy_or_equip_skin(_preview_skin_id)
	if not bool(res.get("ok", false)):
		GameSys.show_toast(String(res.get("reason", "")), "warn")
		return
	_refresh_skin_preview(_preview_skin_id)
	_populate_skin_grid()

func _populate_skin_grid() -> void:
	for c in _skin_grid.get_children():
		c.queue_free()

	for s in FoodDB.get_all_skins():
		var sid := String(s.get("id", "default"))
		var sname := String(s.get("name", sid))
		var price := int(s.get("price", 0))
		var owned := GameSys.is_skin_owned(sid)
		var equipped := (GameSys.get_equipped_skin() == sid)

		var card := _card_panel()
		_skin_grid.add_child(card)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 8)
		card.add_child(cv)

		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		cv.add_child(row)

		var icon := TextureRect.new()
		icon.texture = FoodDB.get_skin_icon(sid)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.custom_minimum_size = Vector2(78, 78)
		row.add_child(icon)

		var mv := VBoxContainer.new()
		mv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(mv)

		var nl := Label.new()
		nl.text = sname
		nl.add_theme_font_size_override("font_size", 21)
		nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		mv.add_child(nl)

		var status_lbl := Label.new()
		status_lbl.add_theme_font_size_override("font_size", 18)
		if equipped:
			status_lbl.text = "✓ Đang mặc"
			status_lbl.add_theme_color_override("font_color", Color(0.45, 1.0, 0.56))
		elif owned:
			status_lbl.text = "Đã sở hữu"
			status_lbl.add_theme_color_override("font_color", Color(0.55, 0.85, 1.0))
		else:
			status_lbl.text = "Giá: %dđ" % price
			status_lbl.add_theme_color_override("font_color", Color(1.0, 0.85, 0.35))
		mv.add_child(status_lbl)

		var preview_btn := _styled_btn("👁 Xem thử 3D" if sid != _preview_skin_id else "✓ Đang xem 3D", Color(0.30, 0.42, 0.62), Vector2(0, 50), 19)
		preview_btn.pressed.connect(func() -> void:
			AudioSys.play_sfx("ui_click")
			_refresh_skin_preview(sid)
			_populate_skin_grid()
		)
		cv.add_child(preview_btn)

func _populate_decor_grid() -> void:
	for c in _decor_grid.get_children():
		c.queue_free()

	for d in FoodDB.get_all_decor():
		var did := String(d.get("id", ""))
		var dname := String(d.get("name", did))
		var price := int(d.get("price", 200))
		var desc := String(d.get("description", ""))

		var card := _card_panel()
		_decor_grid.add_child(card)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 8)
		card.add_child(cv)

		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		cv.add_child(row)

		var icon := TextureRect.new()
		icon.texture = FoodDB.get_decor_icon(did)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.custom_minimum_size = Vector2(78, 78)
		row.add_child(icon)

		var mv := VBoxContainer.new()
		mv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(mv)

		var nl := Label.new()
		nl.text = "%s (%dđ)" % [dname, price]
		nl.add_theme_font_size_override("font_size", 21)
		nl.add_theme_color_override("font_color", Color(1.0, 0.92, 0.46))
		nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		mv.add_child(nl)

		var dl := Label.new()
		dl.text = desc
		dl.add_theme_font_size_override("font_size", 16)
		dl.add_theme_color_override("font_color", Color(0.84, 0.90, 0.96))
		dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		mv.add_child(dl)

		var buy_btn := _styled_btn("Mua & Đặt vào tiệm (%dđ)" % price, Color(0.22, 0.68, 0.42), Vector2(0, 54), 19)
		buy_btn.pressed.connect(func() -> void:
			if GameSys.get_money() < price:
				GameSys.show_toast("Chưa đủ %dđ để mua %s!" % [price, dname], "warn")
				return
			close_shop()
			GameSys.enter_decor_place_mode.emit(did)
		)
		cv.add_child(buy_btn)

func _card_panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var st := StyleBoxFlat.new()
	st.bg_color = Color(0.17, 0.22, 0.32, 0.96)
	st.border_color = Color(0.32, 0.42, 0.58)
	st.set_border_width_all(2)
	st.set_corner_radius_all(18)
	st.content_margin_left = 14
	st.content_margin_right = 14
	st.content_margin_top = 12
	st.content_margin_bottom = 12
	p.add_theme_stylebox_override("panel", st)
	return p

func _styled_btn(txt: String, col: Color, min_sz: Vector2, fsize: int) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = min_sz
	b.add_theme_font_size_override("font_size", fsize)
	_apply_btn_color(b, col)
	return b

func _apply_btn_color(b: Button, col: Color) -> void:
	var st := StyleBoxFlat.new()
	st.bg_color = col
	st.set_corner_radius_all(14)
	var sth := st.duplicate() as StyleBoxFlat
	sth.bg_color = col.lightened(0.14)
	var std := st.duplicate() as StyleBoxFlat
	std.bg_color = Color(0.25, 0.28, 0.32)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", sth)
	b.add_theme_stylebox_override("pressed", st)
	b.add_theme_stylebox_override("disabled", std)
