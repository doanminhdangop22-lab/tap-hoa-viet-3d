extends CanvasLayer

var _title_lbl: Label
var _body_lbl: Label
var _reward_lbl: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 11
	visible = false
	_build_popup_ui()

func _build_popup_ui() -> void:
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.03, 0.05, 0.10, 0.72)
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(720, 0)
	var st := StyleBoxFlat.new()
	st.bg_color = Color(0.14, 0.19, 0.29, 0.98)
	st.border_color = Color(1.0, 0.84, 0.22)
	st.set_border_width_all(4)
	st.set_corner_radius_all(28)
	st.content_margin_left = 36
	st.content_margin_right = 36
	st.content_margin_top = 34
	st.content_margin_bottom = 34
	card.add_theme_stylebox_override("panel", st)
	center.add_child(card)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 20)
	card.add_child(v)

	_title_lbl = Label.new()
	_title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title_lbl.add_theme_font_size_override("font_size", 36)
	_title_lbl.add_theme_color_override("font_color", Color(1.0, 0.90, 0.34))
	v.add_child(_title_lbl)

	_reward_lbl = Label.new()
	_reward_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_reward_lbl.add_theme_font_size_override("font_size", 32)
	_reward_lbl.add_theme_color_override("font_color", Color(0.42, 1.0, 0.56))
	v.add_child(_reward_lbl)

	_body_lbl = Label.new()
	_body_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_body_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_body_lbl.add_theme_font_size_override("font_size", 24)
	_body_lbl.add_theme_color_override("font_color", Color(0.90, 0.95, 1.0))
	v.add_child(_body_lbl)

	var ok_btn := Button.new()
	ok_btn.text = "🎉 Tuyệt vời! Vào bán hàng ngay"
	ok_btn.custom_minimum_size = Vector2(0, 74)
	ok_btn.add_theme_font_size_override("font_size", 26)
	var bst := StyleBoxFlat.new()
	bst.bg_color = Color(0.20, 0.72, 0.38)
	bst.set_corner_radius_all(18)
	ok_btn.add_theme_stylebox_override("normal", bst)
	ok_btn.add_theme_stylebox_override("hover", bst)
	ok_btn.add_theme_stylebox_override("pressed", bst)
	ok_btn.pressed.connect(func() -> void:
		AudioSys.play_sfx("coin_drop")
		visible = false
	)
	v.add_child(ok_btn)

func show_daily_reward(daily_amt: int, streak_amt: int, streak_days: int) -> void:
	_title_lbl.text = "🎁 THƯỞNG MỞ TIỆM MỖI NGÀY!"
	var total := daily_amt + streak_amt
	_reward_lbl.text = "+%dđ VÀO QUỸ TIỆM!" % total
	var lines: Array[String] = [
		"• Thưởng đăng nhập mỗi ngày: +%dđ" % daily_amt,
		"• Chuỗi mở tiệm liên tiếp: %d ngày" % streak_days
	]
	if streak_amt > 0:
		lines.append("🔥 THƯỞNG CHUỖI 7 NGÀY LIÊN TIẾP: +%dđ!" % streak_amt)
	else:
		lines.append("• Đạt đủ 7 ngày liên tiếp nhận thêm +1000đ!")
	_body_lbl.text = "\n".join(lines)
	visible = true
	AudioSys.play_sfx("combo_fire")

func show_store_summary() -> void:
	_title_lbl.text = "📊 THỐNG KÊ TẠP HOÁ"
	_reward_lbl.text = "⭐ %.1f Sao  •  💰 %dđ" % [GameSys.get_rating_stars(), GameSys.get_money()]
	_body_lbl.text = "Tên tiệm: %s\nĐợt khách hiện tại: Cấp %d\nTổng khách đã phục vụ: %d lượt\nTổng doanh thu tích luỹ: %dđ\nChuỗi ngày đăng nhập: %d ngày" % [
		GameSys.get_store_name(),
		GameSys.get_wave_level(),
		int(SaveSys.data.get("total_served", 0)),
		int(SaveSys.data.get("total_earned", 0)),
		int(SaveSys.data.get("login_streak", 1))
	]
	visible = true
	AudioSys.play_sfx("ui_click")
