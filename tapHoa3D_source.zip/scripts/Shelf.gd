extends StaticBody3D

@export var shelf_index: int = 0

var food_id: String = "bim_bim_que"

var _shelf_mesh: MeshInstance3D
var _shelf_mat: StandardMaterial3D
var _canopy_mat: StandardMaterial3D
var _products_root: Node3D
var _product_boxes: Array[MeshInstance3D] = []
var _icon_sprite: Sprite3D
var _name_label: Label3D
var _stock_label: Label3D
var _base_scale: Vector3 = Vector3.ONE

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("shelves")
	_base_scale = scale
	_build_shelf_visuals()
	_sync_assigned_food()
	GameSys.inventory_changed.connect(_on_inventory_changed)
	GameSys.shelf_assignment_changed.connect(_on_shelf_assignment_changed)

func _build_shelf_visuals() -> void:
	var col_shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3(1.56, 1.90, 0.82)
	col_shape.shape = box_shape
	col_shape.position = Vector3(0, 0.95, 0)
	add_child(col_shape)

	_shelf_mesh = MeshInstance3D.new()
	if ResourceLoader.exists("res://assets/models/shelf.obj"):
		_shelf_mesh.mesh = load("res://assets/models/shelf.obj") as Mesh
	else:
		var fallback := BoxMesh.new()
		fallback.size = Vector3(1.5, 1.8, 0.7)
		_shelf_mesh.mesh = fallback
		_shelf_mesh.position = Vector3(0, 0.9, 0)

	_shelf_mat = StandardMaterial3D.new()
	_shelf_mat.albedo_color = Color(0.96, 0.95, 0.92)
	_shelf_mat.roughness = 0.55
	_shelf_mesh.material_override = _shelf_mat
	add_child(_shelf_mesh)

	# Colorful top header strip
	var header := MeshInstance3D.new()
	var hb := BoxMesh.new()
	hb.size = Vector3(1.54, 0.16, 0.74)
	header.mesh = hb
	header.position = Vector3(0, 1.80, 0.02)
	_canopy_mat = StandardMaterial3D.new()
	_canopy_mat.albedo_color = Color(1.0, 0.45, 0.25)
	header.material_override = _canopy_mat
	add_child(header)

	# 12 product slots across 3 shelf tiers (4 per tier)
	_products_root = Node3D.new()
	_products_root.name = "ProductsRoot"
	add_child(_products_root)
	var tier_y := [0.38, 0.91, 1.42]
	var tier_z := [0.08, 0.05, 0.02]
	for t in range(3):
		for slot in range(4):
			var p := MeshInstance3D.new()
			var pb := BoxMesh.new()
			pb.size = Vector3(0.26, 0.24, 0.24)
			p.mesh = pb
			p.position = Vector3(-0.48 + slot * 0.32, float(tier_y[t]), float(tier_z[t]))
			_products_root.add_child(p)
			_product_boxes.append(p)

	# Floating billboard sign above shelf (Icon + Name + Stock)
	var sign_root := Node3D.new()
	sign_root.position = Vector3(0, 2.38, 0)
	add_child(sign_root)

	_icon_sprite = Sprite3D.new()
	_icon_sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_icon_sprite.pixel_size = 0.0052
	_icon_sprite.position = Vector3(0, 0.30, 0)
	_icon_sprite.no_depth_test = false
	sign_root.add_child(_icon_sprite)

	var font := load("res://assets/fonts/BeVietnamPro-ExtraBold.ttf") as Font

	_name_label = Label3D.new()
	_name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_name_label.font = font
	_name_label.font_size = 34
	_name_label.outline_size = 10
	_name_label.modulate = Color(1.0, 0.98, 0.90)
	_name_label.outline_modulate = Color(0.14, 0.10, 0.08)
	_name_label.pixel_size = 0.0042
	_name_label.position = Vector3(0, -0.06, 0)
	sign_root.add_child(_name_label)

	_stock_label = Label3D.new()
	_stock_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_stock_label.font = font
	_stock_label.font_size = 32
	_stock_label.outline_size = 10
	_stock_label.outline_modulate = Color(0.10, 0.10, 0.12)
	_stock_label.pixel_size = 0.0042
	_stock_label.position = Vector3(0, -0.25, 0)
	sign_root.add_child(_stock_label)

func _sync_assigned_food() -> void:
	var assigned := GameSys.get_shelf_foods()
	if shelf_index >= 0 and shelf_index < assigned.size():
		food_id = String(assigned[shelf_index])
	_refresh_visuals()

func _on_shelf_assignment_changed(idx: int, new_food_id: String) -> void:
	if idx == shelf_index:
		food_id = new_food_id
		_refresh_visuals()

func _on_inventory_changed(changed_id: String, _new_amount: int) -> void:
	if changed_id == food_id:
		_refresh_visuals()

func _refresh_visuals() -> void:
	var food := FoodDB.get_food(food_id)
	var stock := GameSys.get_stock(food_id)
	var food_col := Color.from_string(String(food.get("color", "#FF7043")), Color.CORAL)
	var acc_col := Color.from_string(String(food.get("accent_color", "#FFE0B2")), Color.WHEAT)

	if _icon_sprite != null:
		_icon_sprite.texture = FoodDB.get_food_icon(food_id)
		_icon_sprite.modulate = Color.WHITE if stock > 0 else Color(0.45, 0.45, 0.48, 0.85)

	if _name_label != null:
		_name_label.text = String(food.get("name", food_id))

	if _stock_label != null:
		if stock > 0:
			_stock_label.text = "Kho: %d  •  %dđ" % [stock, int(food.get("price", 15))]
			_stock_label.modulate = Color(0.45, 1.0, 0.55) if stock >= 4 else Color(1.0, 0.82, 0.25)
		else:
			_stock_label.text = "HẾT HÀNG!"
			_stock_label.modulate = Color(1.0, 0.32, 0.32)

	if stock > 0:
		_shelf_mat.albedo_color = Color(0.96, 0.95, 0.92)
		_canopy_mat.albedo_color = food_col
	else:
		_shelf_mat.albedo_color = Color(0.34, 0.34, 0.38)
		_canopy_mat.albedo_color = Color(0.28, 0.26, 0.28)

	var p_mat := StandardMaterial3D.new()
	p_mat.albedo_color = food_col
	p_mat.roughness = 0.5
	var p_mat_alt := StandardMaterial3D.new()
	p_mat_alt.albedo_color = acc_col.lerp(food_col, 0.5)
	p_mat_alt.roughness = 0.5

	var visible_boxes := mini(_product_boxes.size(), stock)
	for i in range(_product_boxes.size()):
		var box := _product_boxes[i]
		box.visible = (i < visible_boxes)
		box.material_override = p_mat if (i % 2 == 0) else p_mat_alt

func get_stand_point() -> Vector3:
	return global_position + Vector3(0.0, 0.0, 1.05)

func on_player_interact(player: Node3D) -> void:
	var stock := GameSys.get_stock(food_id)
	var food := FoodDB.get_food(food_id)
	var food_name := String(food.get("name", food_id))
	if stock <= 0:
		AudioSys.play_sfx("customer_angry", 0.08)
		GameSys.show_toast("Kệ %s đã hết hàng! Vào Shop nhập ngay!" % food_name, "warn")
		_play_shake()
		return
	if not player.call("can_add_to_basket"):
		GameSys.show_toast("Giỏ tay đã đầy! Mang ra quầy bán trước nhé!", "warn")
		return
	if bool(player.call("add_to_basket", food_id)):
		GameSys.add_stock(food_id, -1)
		_play_bounce()

func _play_bounce() -> void:
	var tw := create_tween()
	tw.tween_property(self, "scale", _base_scale * Vector3(1.08, 0.92, 1.08), 0.08)
	tw.tween_property(self, "scale", _base_scale, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func _play_shake() -> void:
	var orig_x := position.x
	var tw := create_tween()
	tw.tween_property(self, "position:x", orig_x - 0.08, 0.05)
	tw.tween_property(self, "position:x", orig_x + 0.08, 0.05)
	tw.tween_property(self, "position:x", orig_x, 0.05)
