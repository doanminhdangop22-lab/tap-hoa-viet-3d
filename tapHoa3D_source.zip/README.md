# 🏪 Tạp Hoá Việt 3D (Godot 4.3 — Android APK, iPhone/iOS PWA & PC)

Game 3D mô phỏng quản lý tiệm tạp hoá / đồ ăn vặt Việt Nam phong cách Low-Poly tươi sáng, hoàn chỉnh bằng **Godot 4.3 (GDScript)**.

---

## 🎮 1. Chơi thử ngay trên Máy Tính (PC)

Mở thư mục `tapHoa3D` trong `Downloads` và nhấp đúp vào:
👉 **`Nhấn vào đây để chơi`**

### Bộ điều khiển tích hợp trên Máy Tính (PC) & Điện Thoại:
| Thao tác | Trên Máy Tính (PC) | Trên Android & iPhone |
| :--- | :--- | :--- |
| **Di chuyển** | `W A S D` hoặc phím `Mũi tên ↑↓←→` (hoặc Click chuột lên sàn) | Cần gạt ảo (Joystick góc dưới trái) hoặc Chạm sàn |
| **Lấy đồ & Bán hàng tự động** | **Click chuột trái** thẳng vào Kệ hàng / Quầy thu ngân | **Chạm** thẳng vào Kệ hàng / Quầy thu ngân |
| **Tương tác nhanh gần nhất** | Phím `E` hoặc `Space` | Nút `🖐 Lấy / Bán hàng` góc dưới phải |
| **Trả lại món cầm nhầm** | Phím `Q` hoặc `Backspace` | Nút `↩ Trả kệ` trên khung giỏ hàng |
| **Mở Shop (Nhập kho / Skin / Nội thất)** | Phím `B` | Nút `🛒 Shop` |
| **Chế độ Trang trí 3D** | Phím `V` (`R` để xoay 45°, `X`/`Delete` xoá hoàn 50% tiền) | Nút `🎨 Trang trí` (Kéo thả trên sàn, Xoay, Xoá) |
| **Bật / Tắt đèn tiệm** | Phím `L` | Nút `💡 Đèn` góc trên trái |
| **Tạm dừng / Đổi tên bảng LED** | Phím `Esc` | Nút `☰` góc trên phải hoặc nút Back Android |
| **Toàn màn hình (PC)** | Phím `F11` | Tự động toàn màn hình |

---

## 📱 2. Tự động Build `.apk` (Android) & Bản chơi trên iPhone bằng GitHub

Thư mục đã tích hợp sẵn GitHub Actions tại `.github/workflows/build.yml` và `export_presets.cfg`:

1. Tạo một Repository mới trên GitHub (ví dụ `tap-hoa-3d`).
2. Đẩy toàn bộ nội dung thư mục `tapHoa3D` lên nhánh `main` (bằng Git hoặc kéo thả lên GitHub):
   ```bash
   git init
   git add .
   git commit -m "Initial release Tap Hoa Viet 3D"
   git branch -M main
   git remote add origin https://github.com/<ten-cua-ban>/<ten-repo>.git
   git push -u origin main
   ```
3. Vào tab **Actions** trên GitHub, đợi khoảng 2–3 phút để workflow **Build Tap Hoa 3D (Android APK & iPhone WebApp)** chạy xong (tích xanh ✅):
   - **Trên Android**: Tải file trong mục **Artifacts -> `TapHoaViet3D-Android-APK`**, giải nén lấy `TapHoaViet3D.apk` cài đặt và chơi ngay!
   - **Trên iPhone (iOS) & Trình duyệt di động**:
     - Vào **Settings -> Pages** trên GitHub Repo, phần *Build and deployment -> Source* chọn **GitHub Actions**.
     - Mở đường link GitHub Pages bằng **Safari trên iPhone** -> Nhấn nút **Chia sẻ (Share)** -> **Thêm vào MH chính (Add to Home Screen)** để cài làm ứng dụng toàn màn hình mượt 60FPS trên iPhone mà không cần chứng chỉ Apple Developer trả phí!

---

## ✨ 3. Tính năng nổi bật trong Game

- **48 món ăn vặt Việt Nam** chia 5 nhóm (*Snack mặn, Đồ ngọt, Nước uống, Mì & Cháo, Kem & Lạnh*) với bộ icon vẽ riêng từng món tại `assets/textures/foods/`.
- **Hệ thống Khách hàng đa dạng** (tối đa 6 khách cùng lúc, tăng dần theo cấp độ Wave):
  - **Khách thường**: Mua 1 món.
  - **Khách VIP (👑)**: Mua 2–3 món, thưởng **Tip x2**.
  - **Khách trẻ em (🍬)**: Thích đồ ngọt & kem, thanh kiên nhẫn giảm nhanh hơn.
  - **Khách vội (⚡)**: Thanh kiên nhẫn giảm nhanh gấp đôi, phục vụ kịp thưởng **Tip x3**.
- **8 Kệ hàng 3D + Kho nhập hàng phía sau + Quầy thu ngân**:
  - Cho phép đổi món trưng bày tự do trên từng kệ, hiệu ứng thùng carton rơi vào kho khi nhập hàng, kệ tối màu & báo hết hàng khi kho về 0.
- **Kinh tế, Combo & Điểm thưởng**:
  - Khởi đầu `500đ`, bán 5 món cùng loại trong 1 phút kích hoạt **🔥 Combo x1.5 tiền**, thưởng mở game mỗi ngày **+200đ** và chuỗi 7 ngày liên tiếp **+1000đ**.
- **6 Skin Nhân vật (Xem thử trực tiếp 3D xoay 360°)** & **8 Đồ nội thất Trang trí (Kéo thả 3D, xoay góc, bán hoàn 50% tiền, Loa phát nhạc mở khoá thêm kênh BGM)**.
- **Auto-Save (`user://save.json`)**: Tự động lưu mỗi 30 giây và khi tạm dừng / thoát game.
