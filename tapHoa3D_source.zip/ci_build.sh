#!/usr/bin/env bash
set -euxo pipefail

yes | sdkmanager --licenses || true
sdkmanager "platform-tools" "build-tools;34.0.0" "platforms;android-34"

wget -q https://github.com/godotengine/godot/releases/download/4.3-stable/Godot_v4.3-stable_linux.x86_64.zip
wget -q https://github.com/godotengine/godot/releases/download/4.3-stable/Godot_v4.3-stable_export_templates.tpz
unzip -q Godot_v4.3-stable_linux.x86_64.zip
chmod +x Godot_v4.3-stable_linux.x86_64
sudo mv Godot_v4.3-stable_linux.x86_64 /usr/local/bin/godot
mkdir -p ~/.local/share/godot/export_templates/4.3.stable
unzip -q Godot_v4.3-stable_export_templates.tpz
mv templates/* ~/.local/share/godot/export_templates/4.3.stable/
rm -rf Godot_v4.3-stable_linux.x86_64.zip Godot_v4.3-stable_export_templates.tpz templates

KEYSTORE_PATH="/tmp/debug.keystore"
rm -f "$KEYSTORE_PATH"
keytool -genkeypair -v \
  -keystore "$KEYSTORE_PATH" \
  -storepass android \
  -alias androiddebugkey \
  -keypass android \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -dname "CN=TapHoa3D,O=Game,C=VN"

mkdir -p ~/.config/godot
godot --headless --editor --quit || true

cat <<EOF > ~/.config/godot/editor_settings-4.3.tres
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "${ANDROID_HOME}"
export/android/debug_keystore = "${KEYSTORE_PATH}"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOF
cp ~/.config/godot/editor_settings-4.3.tres ~/.config/godot/editor_settings-4.tres

export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$KEYSTORE_PATH"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER="androiddebugkey"
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD="android"

mkdir -p build/android build/web
godot --headless --editor --quit || true
godot --headless --export-debug "Android" build/android/TapHoaViet3D.apk
godot --headless --export-release "Web" build/web/index.html
cp web/apple-touch-icon.png build/web/apple-touch-icon.png || true

ls -lh build/android/TapHoaViet3D.apk build/web/

if [ -n "${GH_TOKEN:-}" ]; then
  gh release create v1.0.0 build/android/TapHoaViet3D.apk \
    --title "Tap Hoa Viet 3D v1.0.0 (Android APK)" \
    --notes "Cai dat TapHoaViet3D.apk cho Android." || \
  gh release upload v1.0.0 build/android/TapHoaViet3D.apk --clobber || true
fi

if [ -f tapHoa3D_source.zip ]; then
  rm -f tapHoa3D_source.zip
  git config user.name "github-actions[bot]"
  git config user.email "github-actions[bot]@users.noreply.github.com"
  git add -A
  git commit -m "Unpack full Tap Hoa Viet 3D project tree [skip ci]" || true
  git push || true
fi