Thư mục cấu hình xuất bản Android cho Godot 4.3.
File cấu hình APK chính nằm tại ../export_presets.cfg (Package: vn.taphoa3d.game).
Khi đẩy thư mục tapHoa3D lên GitHub, workflow tại ../.github/workflows/build.yml sẽ tự động cài đặt Android SDK 34, ký APK và xuất file TapHoaViet3D.apk trong mục Actions -> Artifacts.
